// created on 24/05/2003 at 11:12
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace PictureDisplayer {
	public class Saver : System.Windows.Forms.Form
	{
		private GroupBox grExtension;
		private RadioButton rbBMP;
		private RadioButton rbJPG;
		private RadioButton rbGIF;
		private RadioButton rbPNG;
		
		private Label niveau;
		private NumericUpDown compression;
		
		private Button btnSaveAs;
		private Button btnCancel;
		
		private Image image;
		
		public bool succes;
		public string picPath;
		
		public Saver(Image image)
		{
			this.image = image;
			InitializeComponent();
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.ShowInTaskbar = false;
		}
		
		private void InitializeComponent() {
			this.grExtension = new GroupBox();
			this.grExtension.Text = "Type de fichier a enregistrer :";
			this.grExtension.Parent = this;
			this.grExtension.Location = new System.Drawing.Point(10, 10);
			
			this.rbBMP = new RadioButton();
			this.rbBMP.Parent = this.grExtension;
			this.rbBMP.Text = "BMP";
			this.rbBMP.Checked = true;
			this.rbBMP.Location = new System.Drawing.Point(5, 15);
			this.rbBMP.FlatStyle = FlatStyle.System;
			
			this.rbJPG = new RadioButton();
			this.rbJPG.Parent = this.grExtension;
			this.rbJPG.Text = "JPG";
			this.rbJPG.Location = new System.Drawing.Point(5, this.rbBMP.Bottom + 5);
			this.rbJPG.FlatStyle = FlatStyle.System;
			this.rbJPG.CheckedChanged += new EventHandler(Compression);
			
			this.rbGIF = new RadioButton();
			this.rbGIF.Parent = this.grExtension;
			this.rbGIF.Text = "GIF";
			this.rbGIF.Location = new System.Drawing.Point(5, this.rbJPG.Bottom + 5);
			this.rbGIF.FlatStyle = FlatStyle.System;
			
			this.rbPNG = new RadioButton();
			this.rbPNG.Parent = this.grExtension;
			this.rbPNG.Text = "PNG";
			this.rbPNG.Location = new System.Drawing.Point(5, this.rbGIF.Bottom + 5);
			this.rbPNG.FlatStyle = FlatStyle.System;
			
			this.grExtension.Height = this.rbPNG.Bottom + 10;
			
			this.niveau = new Label();
			this.niveau.Parent = this;
			this.niveau.Text = "Niveau de compression :";
			this.niveau.AutoSize  = true;
			this.niveau.Enabled = false;
			this.niveau.Location = new System.Drawing.Point(10, this.grExtension.Bottom + 10);
			
			this.compression = new NumericUpDown();
			this.compression.Parent = this;
			this.compression.Minimum = 1;
			this.compression.Maximum = 99;
			this.compression.TextAlign = HorizontalAlignment.Right;
			this.compression.Enabled = false;
			this.compression.Location = new System.Drawing.Point(this.niveau.Right + 5, this.grExtension.Bottom + 10);
			this.compression.Size = new System.Drawing.Size(50, 15);
			
			this.btnSaveAs = new Button();
			this.btnSaveAs.Parent = this;
			this.btnSaveAs.Text = "Enregistrer sous...";
			this.btnSaveAs.Width = 7 * Font.Height;
			this.btnSaveAs.FlatStyle = FlatStyle.System;
			this.btnSaveAs.Click += new EventHandler(Save);
			this.btnSaveAs.Location = new System.Drawing.Point(10, this.compression.Bottom + 5);
			
			this.btnCancel = new Button();
			this.btnCancel.Parent = this;
			this.btnCancel.Text = "Annuler";
			this.btnCancel.Width = 7 * Font.Height;
			this.btnCancel.FlatStyle = FlatStyle.System;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(this.btnSaveAs.Right + 10, this.compression.Bottom + 5);
			
		}
		
		private void Compression(object obj, EventArgs ea) {
			RadioButton rb = (RadioButton)obj;
			
			if(rb.Checked)
			{
				this.niveau.Enabled = true;
				this.compression.Enabled = true;
			}
			else
				{
					this.niveau.Enabled = false;
					this.compression.Enabled = false;
				}
		}
		
		private void Save(object obj, EventArgs ea) {
			SaveFileDialog sfd = new SaveFileDialog();
			if(this.rbBMP.Checked)
			{
				sfd.Filter = "Fichier bitmap (*.bmp)|*.bmp";
			}
			else if(this.rbJPG.Checked)
			{
				sfd.Filter = "Fichier JPEG (*.jpg)|*.jpg";
			}
			if(this.rbGIF.Checked)
			{
				sfd.Filter = "Fichier GIF (*.gif)|*.gif";
			}
			if(this.rbPNG.Checked)
			{
				sfd.Filter = "Fichier PNG (*.png)|*.png";
			}
			
			if(sfd.ShowDialog() == DialogResult.OK)
			{
				try
				{
					if(!this.niveau.Visible)
					{
						this.image.Save(sfd.FileName);
					}
					else
						{
							ImageCodecInfo jpeg = null;
							foreach(ImageCodecInfo ici in ImageCodecInfo.GetImageEncoders())
							{
								if(ici.MimeType == "image/jpeg")
								{
									jpeg = ici;
									break;
								}
							}
							if(jpeg == null)
							{
								MessageBox.Show("Codec Jepg introuvables.\nImpossible d'enregistrer cette image en Jpeg.", "PictureViewer");
								return;
							}
							EncoderParameters epJpeg = new EncoderParameters(1);
							long[] alQuality = new long[1];
							alQuality[0] = (long)(100 - this.compression.Value);
							epJpeg.Param[0] = new EncoderParameter(Encoder.Quality, alQuality);
							this.image.Save(sfd.FileName, jpeg, epJpeg);
						}
				}
				catch(Exception e)
				{
					MessageBox.Show(e.ToString(), "PictureViewer");
					return;
				}
			}
			this.picPath = sfd.FileName;
			this.succes = true;
			this.Close();
		}
	}
}
