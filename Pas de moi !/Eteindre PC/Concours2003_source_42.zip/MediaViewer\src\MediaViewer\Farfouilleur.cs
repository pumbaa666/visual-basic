using System;
using System.IO;
using System.Windows.Forms;

namespace MediaViewer
{
	class Farfouilleur : System.Windows.Forms.Form
	{
		private string type;
		private string filtre;
		
		private ulong trouves;
		
		private ColumnHeader col1;
		
		private RichListView listView;
		
		private System.Threading.Thread Farfouille = null;
		
		public Farfouilleur(string s) {
			this.trouves = 0;
			this.type = s;
			this.listView = new RichListView(s);
			this.listView.Parent = this;
			this.listView.farfouilleur = true;
			this.listView.Dock = DockStyle.Fill;
			this.listView.View = System.Windows.Forms.View.Details;
			this.col1 = new ColumnHeader();
			this.col1.Width = this.ClientSize.Width;
			this.col1.Text = "Nom";
			this.listView.Columns.Add( col1 );
			
			Filtre f = new Filtre();
			f.ShowDialog();
			this.filtre = f.tb.Text;
			
			StartRecherche();
		}
		
		private void StartRecherche() {
			if (Farfouille!=null)
			{
				Farfouille.Abort();
				Farfouille = null;
			}
			Farfouille = new System.Threading.Thread(new System.Threading.ThreadStart(RechercheUnitesLogiques));
			Farfouille.Priority = System.Threading.ThreadPriority.Lowest;
			Farfouille.IsBackground = true;
			Farfouille.Start();
		}
		
		private void RechercheUnitesLogiques() {
			string[] unites = Environment.GetLogicalDrives();
			
			foreach(string s in unites)
			{
				RechercheDossier(s);
			}
		}
		
		private void RechercheDossier(string s) {
			string[] fichiers;
			string[] repertoires;
			try
			{
				fichiers = System.IO.Directory.GetFiles(s);
				repertoires = System.IO.Directory.GetDirectories(s);
			}
			catch(Exception e)
			{
				MessageBox.Show(e.ToString() + "\nLa recherche dans ce dossier va s'arreter !", "MediaViewer");
				return;
			}
			
			foreach(string fichier in fichiers)
			{
				System.IO.FileInfo fInfo = new System.IO.FileInfo(fichier);
				
				if((fInfo.Attributes & FileAttributes.System) != 0)
				{
					continue;
				}
				
				switch(this.type)
				{
					case "img" :	if(IsPicture(fichier))
									{
										string nom = Path.GetFileName(fichier);
										if((filtre != "") && (IsInside(nom, filtre)))
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										else if(filtre == "")
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										MakeCaption();
									}
									break;
					case "mus" :	if((IsMusique(fichier)) || (IsPlayList(fichier)))
									{
										string nom = Path.GetFileName(fichier);
										if((filtre != "") && (IsInside(nom, filtre)))
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										else if(filtre == "")
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										MakeCaption();
									}
									break;
					case "vid" :	if(IsVideo(fichier))
									{
										string nom = Path.GetFileName(fichier);
										if((filtre != "") && (IsInside(nom, filtre)))
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										else if(filtre == "")
										{
											this.listView.Items.Add(fichier);
											trouves++;
										}
										MakeCaption();
									}
									break;
					default: break;
				}
			}
			
			foreach(string repertoire in repertoires)
			{
				if(repertoire.ToUpper() == "SYSTEM VOLUME INFORMATION")
				{
					continue;
				}
				RechercheDossier(Path.Combine(s, repertoire));
			}
		}
		
		private bool IsPicture(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".JPG") || path.EndsWith(".JPEG") || path.EndsWith(".BMP") || path.EndsWith(".GIF") || path.EndsWith(".PNG") || path.EndsWith(".ICO"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsPlayList(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".M3U") ||path.EndsWith(".PLS"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsMusique(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".MP3") || path.EndsWith(".WAV") || path.EndsWith(".OGG") || path.EndsWith(".WMA"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsVideo(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".AVI") || path.EndsWith(".MPEG") || path.EndsWith(".MPG") || path.EndsWith(".MOV") ||path.EndsWith(".VOB"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		protected override void OnResize(EventArgs ea) {
			base.OnResize(ea);
			this.col1.Width = this.ClientSize.Width;
		}
		
		protected override void OnClosed(EventArgs ea) {
			base.OnClosed(ea);
			if (Farfouille!=null)
			{
				Farfouille.Abort();
				Farfouille = null;
			}
		}
		
		private bool IsInside(string chaine, string occurence) {
			chaine = chaine.ToUpper();
			occurence = occurence.ToUpper();
			int i = 0;
			string str;
			while(chaine.Length >= occurence.Length + i)
			{
				str = chaine.Substring(i, occurence.Length);
				if(str == occurence)
				{
					return true;
				}
				i++;
			}
			return false;
		}
		
		private void MakeCaption() {
			this.Text = trouves.ToString() + " fichiers trouves";
		}
	}
}
