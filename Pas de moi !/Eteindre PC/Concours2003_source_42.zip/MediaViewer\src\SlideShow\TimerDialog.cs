// created on 01/06/2003 at 12:12
using System;
using System.Windows.Forms;

namespace SlideShow {
	public class TimerDialog : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label;
		public System.Windows.Forms.NumericUpDown numTick;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Button btnCancel;
		
		public TimerDialog()
		{
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			InitializeComponent();
		}
		
		void InitializeComponent() {
			this.label = new System.Windows.Forms.Label();
			this.label.Parent = this;
			this.label.Text = "Intervalle entre 2 images en millisecondes : ";
			this.label.Location = new System.Drawing.Point(10, 10);
			this.label.AutoSize = true;
			
			this.numTick = new System.Windows.Forms.NumericUpDown();
			this.numTick.Parent = this;
			this.numTick.Location = new System.Drawing.Point(this.label.Right + 5, 10);
			this.numTick.Size = new System.Drawing.Size(100, 12);
			this.numTick.TextAlign = HorizontalAlignment.Right;
			this.numTick.DecimalPlaces = 0;
			this.numTick.Increment = 1m;
			this.numTick.Minimum = 0;
			this.numTick.Maximum = 2147483647;
			
			this.btnOk = new System.Windows.Forms.Button();
			this.btnOk.Parent = this;
			this.btnOk.FlatStyle = FlatStyle.System;
			this.btnOk.Text = "Ok";
			this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOk.Location = new System.Drawing.Point(10, this.numTick.Bottom + 5);
			
			this.ClientSize = new System.Drawing.Size(this.numTick.Right + 10, this.btnOk.Bottom + 10);
			
			this.btnOk.Location = new System.Drawing.Point(this.ClientSize.Width - 2*this.btnOk.Width - 10, this.numTick.Bottom + 5);
			
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnCancel.Parent = this;
			this.btnCancel.FlatStyle = FlatStyle.System;
			this.btnCancel.Text = "Annuler";
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(this.ClientSize.Width - this.btnCancel.Width - 5, this.numTick.Bottom + 5);
			
		}
	}
}
