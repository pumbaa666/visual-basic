using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace PictureDisplayer {
	public class PictureDisplayer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ProgressBar progressBar;
		
		private System.Threading.Thread Effet = null;
		
		Bitmap image;
		Bitmap img;
		Color ctmp;
		Color color;
		
		string picturePath;
		
		bool erreur;
		
		MenuItem miEffet;
		MenuItem miFichier;
		
		///<summary>
		/// Constructeur de la classe
		/// initialise toutes les proprietes,
		/// appel InitializeComponent et InitializeMenus
		/// <param name="PicturePath">chemin de l'image a afficher</param>
		///</summary>
		public PictureDisplayer(string PicturePath) {
			this.picturePath = PicturePath;
			this.AutoScroll = true;
			this.ShowInTaskbar = false;
			this.Text = PicturePath;
			erreur = false;
			try
			{
				img = (Bitmap)Image.FromFile(PicturePath);
				image = new Bitmap(img.Width, img.Height, PixelFormat.Format32bppArgb);
				image = (Bitmap)img.GetThumbnailImage(img.Width, img.Height, null, (IntPtr)0);
			}
			catch (Exception e)
			{
				MessageBox.Show("Impossible d'ouvrir " + PicturePath, "Viewer\n" + e.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
				erreur = true;
			}
			InitializeComponent();
			this.progressBar.Parent = this;
			InitializeMenus();
			InitializeSize();
			this.progressBar.Visible = false;
			this.progressBar.Maximum = this.image.Height;
		}
		
		///<summary>
		/// On override la methode parente pour fermer la Form si il y a eu une erreur dans le construvteur
		/// <param name="ea">EventArgs obligatoires pour la methode OnLoad()</param>
		///</summary>
		protected override void OnLoad(EventArgs ea) {
			base.OnLoad(ea);
			if(erreur)
				this.Close();
		}
		
		///<summary>
		/// Methode qui initialise les composants.
		/// Attention, cette methode n'est peut-etre pas compatible avec les editeurs WYSIWYG
		///</summary>
		void InitializeComponent() {
			this.progressBar = new System.Windows.Forms.ProgressBar();
			this.SuspendLayout();
			// 
			// progressBar
			// 
			this.progressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.progressBar.Location = new System.Drawing.Point(0, 251);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(292, 15);
			this.progressBar.TabIndex = 0;
			// 
			// PictureDisplayer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
						this.progressBar});
			this.Name = "PictureDisplayer";
			this.ResumeLayout(false);
		}
		
		///<summary>
		/// Methode d'initialisation des menus
		///</summary>
		void InitializeMenus() {
			Menu				= new MainMenu();
			miFichier	= new MenuItem();
			miFichier.Text		= "&Fichier";
			miEffet	= new MenuItem();
			miEffet.Text		= "&Effet";
			
			RichMenuItem miImprimer		= new RichMenuItem();
			miImprimer.Text				= "Imprimer";
			miImprimer.Shortcut			= Shortcut.CtrlP;
			miImprimer.Click			+= new EventHandler(Imprimer);
			
			RichMenuItem miFichierSave	= new RichMenuItem();
			miFichierSave.Text			= "Enregistrer";
			miFichierSave.Click			+= new EventHandler(Save);
			miFichierSave.Shortcut		= Shortcut.CtrlS;
			
			RichMenuItem miFichierFermer = new RichMenuItem();
			miFichierFermer.Text		 = "&Fermer";
			miFichierFermer.Click		+= new EventHandler(MenuClose);
			miFichierFermer.Shortcut	 = Shortcut.AltF4;
			
			RichMenuItem miEffetGris		 = new RichMenuItem();
			miEffetGris.Text		 = "&Niveaux de gris";
			miEffetGris.Click		+= new EventHandler(StartNiveauxDeGris);
			RichMenuItem miEffetNB		 = new RichMenuItem();
			miEffetNB.Text		 = "Noir et Blanc";
			miEffetNB.Click		+= new EventHandler(StartNoirEtBlanc);
			
			RichMenuItem miEffetInverse	= new RichMenuItem();
			miEffetInverse.Text			= "&Inverser les couleurs";
			miEffetInverse.Click		+= new EventHandler(StartInverse);
			
			RichMenuItem miEffetFiltre	= new RichMenuItem();
			miEffetFiltre.Text			= "&Filtre";
			miEffetFiltre.Click			+= new EventHandler(StartFiltreAdd);
			
			RichMenuItem miEffetRotation = new RichMenuItem();
			miEffetRotation.Text		 = "&Rotation";
			RichMenuItem miEffetRotation90 = new RichMenuItem();
			miEffetRotation90.Text		 = "90";
			miEffetRotation90.Click		+= new EventHandler(Rotation90);
			RichMenuItem miEffetRotation180 = new RichMenuItem();
			miEffetRotation180.Text		 = "180";
			miEffetRotation180.Click		+= new EventHandler(Rotation180);
			RichMenuItem miEffetRotation270 = new RichMenuItem();
			miEffetRotation270.Text		 = "270";
			miEffetRotation270.Click	+= new EventHandler(Rotation270);
			
			RichMenuItem miEffetFlip = new RichMenuItem();
			miEffetFlip.Text		 = "&Flip";
			RichMenuItem miEffetFlipHB = new RichMenuItem();
			miEffetFlipHB.Text		 = "&Haut<->Bas";
			miEffetFlipHB.Click		+= new EventHandler(FlipHB);
			RichMenuItem miEffetFlipGD = new RichMenuItem();
			miEffetFlipGD.Text		 = "&Gauche<->Droite";
			miEffetFlipGD.Click		+= new EventHandler(FlipGD);
			
			RichMenuItem miEffetResize = new RichMenuItem();
			miEffetResize.Text = "Redimensionner";
			miEffetResize.Click += new EventHandler(ResizeImage);
			
			RichMenuItem miEffetZoom = new RichMenuItem();
			miEffetZoom.Text		 = "&Zoom";
			miEffetZoom.Click		+= new EventHandler(Zoom);
			
			
			
			Menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[]{miFichier,
																		miEffet});
			miFichier.MenuItems.AddRange(new System.Windows.Forms.MenuItem[]{	miFichierSave,
																				new Separateur(),
																				miImprimer,
																				new Separateur(),
																				miFichierFermer});
			miEffet.MenuItems.AddRange(new System.Windows.Forms.MenuItem[]{ miEffetGris,
																			miEffetNB,
																			new Separateur(),
																			miEffetInverse,
																			miEffetFiltre,
																			new Separateur(),
																			miEffetRotation,
																			miEffetFlip,
																			miEffetResize,
																			new Separateur(),
																			miEffetZoom});
			miEffetRotation.MenuItems.AddRange(new System.Windows.Forms.MenuItem[]{ miEffetRotation90,
																					miEffetRotation180,
																					miEffetRotation270});
			miEffetFlip.MenuItems.AddRange(new System.Windows.Forms.MenuItem[]{ miEffetFlipHB,
																				miEffetFlipGD});
		}
		
		///<summary>
		/// Methode d'impression
		/// Cette methode est une adaptation d'un exemple de Charles Petzold dans "Programmer Microsft Windows avec C#"
		/// <param name="obj">object representant le menu appelant</param>
		/// <param name="ea">EventArgs envoye par le menu appelant</param>
		///</summary>
		private void Imprimer(object obj, EventArgs ea) {
			PageSetupDialog setDlg = new PageSetupDialog();
			PrintDialog prntDlg = new PrintDialog();
			System.Drawing.Printing.PrintDocument prntDoc = new System.Drawing.Printing.PrintDocument();
			
			prntDoc.PrintPage += new PrintPageEventHandler(OnPrintPage);
			setDlg.Document = prntDoc;
			prntDlg.Document = prntDoc;
			
			if(prntDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				prntDoc.DocumentName = Text;
				prntDoc.Print();
			}
		}
		
		///<summary>
		/// Methode necessaire a l'impression
		/// Cette methode est egalement un exemple de Charles Petzold dans "Programmer Microsft Windows avec C#"
		/// <param name="obj">object envoye par le PrintPageEvetHandler</param>
		/// <param name="ppea">toujours le PrintPageEventHandler</param>
		///</summary>
		private void OnPrintPage(object obj, PrintPageEventArgs ppea) {
			Graphics grfx = ppea.Graphics;
			RectangleF rectf = new RectangleF(	ppea.MarginBounds.Left - (ppea.PageBounds.Width - grfx.VisibleClipBounds.Width) / 2,
												ppea.MarginBounds.Top - (ppea.PageBounds.Height - grfx.VisibleClipBounds.Height) / 2,
												ppea.MarginBounds.Width,
												ppea.MarginBounds.Height);
			ScaleImageIsotropically(grfx, image, rectf);
		}
		
		///<summary>
		/// Methode de redimension de l'image courante
		/// Appelle un Sizer pour demander a l'utilisateur la nouvelle taille de l'image
		/// <param name="obj">object representant le menu appelant</param>
		/// <param name="ea">EventArgs envoye par le menu appelant</param>
		///</summary>
		private void ResizeImage(object obj, EventArgs ea) {
			Sizer size = new Sizer();
			size.txtlong.Value = this.image.Width;
			size.txthaut.Value = this.image.Height;
			size.Text = "Original : " + this.image.Width.ToString() + "*" +this.image.Height.ToString();
			size.ShowDialog();
			
			this.image = (Bitmap)this.image.GetThumbnailImage((int)size.txtlong.Value, (int)size.txthaut.Value, null, (IntPtr)0);
			this.Invalidate();
		}
		
		///<summary>
		/// Methode qui dimensionne la zone client en fonction de la taille de l'image
		///</summary>
		private void InitializeSize() {
			if(((System.Windows.Forms.Screen.PrimaryScreen.Bounds.Size.Width / 2) < image.Width) || ((System.Windows.Forms.Screen.PrimaryScreen.Bounds.Size.Height / 2) < image.Height))
			{
				this.ClientSize = new Size(System.Windows.Forms.Screen.PrimaryScreen.Bounds.Size.Width / 2, System.Windows.Forms.Screen.PrimaryScreen.Bounds.Size.Height / 2);
			}
			else
			{
				this.ClientSize = new Size(image.Width, image.Height);
			}
		}
		
		///<summary>
		/// Methode pour enregistrer l'image courante
		/// <param name="obj">object representant le menu appelant</param>
		/// <param name="ea">EventArgs envoye par le menu appelant</param>
		///</summary>
		private void Save(object obj, EventArgs ea) {
			Saver save = new Saver(this.image);
			save.ShowDialog();
			if(save.succes)
			{
				this.picturePath = save.picPath;
			}
			save.Dispose();
			MakeCaption();
			this.image = (Bitmap)Image.FromFile(this.picturePath);
			this.Invalidate();
		}
		
		///<summary>
		/// Methode qui change le texte de la Form
		///</summary>
		private void MakeCaption() {
			this.Text = this.picturePath;
		}
		
		///<summary>
		/// Methode pour fermer la Form
		/// <param name="obj">object representant le menu appelant</param>
		/// <param name="ea">EventArgs envoye par le menu appelant</param>
		///</summary>
		private void MenuClose(object obj, EventArgs ea) {
			this.Close();
		}
		
		///<summary>
		/// Methode pour dessiner l'image dans la zone client
		/// <param name="pea">PaintEventArgs obligatoires pour la methode OnLoad()</param>
		///</summary>
		protected override void OnPaint(PaintEventArgs pea) {
			base.OnPaint(pea);
			try
			{
				if(image == null)
				{
					return;
				}
				ScaleIsotropicaly(pea.Graphics, new Rectangle(0, 0, ClientSize.Width, ClientSize.Height));
			}
			catch
			{
				return;
			}
		}
		
		protected override void OnResize(EventArgs ea) {
			base.OnResize(ea);
			this.Invalidate();
		}
		
		private void ScaleIsotropicaly(Graphics grfx, Rectangle rect) {
			SizeF sizef = new SizeF(image.Width / image.HorizontalResolution, image.Height / image.VerticalResolution);
			float fScale = Math.Min(rect.Width / sizef.Width, rect.Height / sizef.Height);
			sizef.Width *= fScale;
			sizef.Height *= fScale;
			grfx.DrawImage(image, rect.X + (rect.Width - sizef.Width) / 2, rect.Y + (rect.Height - sizef.Height) / 2, sizef.Width, sizef.Height);
		}
		
		private void ScaleImageIsotropically(Graphics grfx, Image image, RectangleF rectf) {
			SizeF sizef = new SizeF(image.Width / image.HorizontalResolution, image.Height / image.VerticalResolution);
			float fScale = Math.Min(rectf.Width / sizef.Width, rectf.Height / sizef.Height);
			sizef.Width *= fScale;
			sizef.Height *= fScale;
			grfx.DrawImage(image, rectf.X + (rectf.Width - sizef.Width) / 2, rectf.Y + (rectf.Height - sizef.Height) / 2, sizef.Width, sizef.Height);
		}
		
		private void Zoom(object obj, EventArgs ea) {
			try
			{
				Process.Start(Environment.CurrentDirectory + "\\Zoomer.exe", "\"" + this.picturePath + "\"");
			}
			catch
			{
				MessageBox.Show(Environment.CurrentDirectory + "\\Zoomer.exe", "\"" + this.picturePath + "\"");
			}
		}
		
		private void BeginEffet() {
			this.progressBar.Maximum = image.Height * image.Width;
			this.miEffet.Enabled = false;
			this.miFichier.Enabled = false;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		}
		
		private void EndEffet() {
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
			this.miFichier.Enabled = true;
			this.miEffet.Enabled = true;
			this.progressBar.Visible = false;
		}
		
		public void StartInverse(object obj, EventArgs ea) {
			if (Effet!=null)
			{
				Effet.Abort();
				Effet = null;
			}
			Effet = new System.Threading.Thread(new System.Threading.ThreadStart(Inverse));
			Effet.Priority = System.Threading.ThreadPriority.Lowest;
			Effet.IsBackground = true;
			Effet.Start();
			this.progressBar.Visible = true;
		}
		
		private void Inverse() {
			BeginEffet();
			ctmp = new Color();
			int x;
			int y;
			
			for(x=0; x<image.Height; x++)
			{
				for(y=0; y<image.Width; y++)
				{
					ctmp = image.GetPixel(y, x);
					ctmp = Color.FromArgb(ctmp.A, 255 - ctmp.R, 255 - ctmp.G, 255 - ctmp.B);
					image.SetPixel(y, x, ctmp);
				}
				this.progressBar.Value += y;
			}
			this.Invalidate();
			EndEffet();
			this.progressBar.Value = 0;
		}
		
		public void StartFiltreAdd(object obj, EventArgs ea) {
			if (Effet!=null)
			{
				Effet.Abort();
				Effet = null;
			}
			Effet = new System.Threading.Thread(new System.Threading.ThreadStart(FiltreAdd));
			Effet.Priority = System.Threading.ThreadPriority.Lowest;
			Effet.IsBackground = true;
			Effet.Start ();
			this.progressBar.Visible = true;
		}
		
		private void FiltreAdd() {
			ColorDialog cd = new ColorDialog();
			if(cd.ShowDialog() != DialogResult.OK)
			{
				EndEffet();
				return;
			}
			BeginEffet();
			this.color = cd.Color;
			
			ctmp = new Color();
			int x;
			int y;
			
			for(x=0; x<image.Height; x++)
			{
				for(y=0; y<image.Width; y++)
				{
					ctmp = image.GetPixel(y, x);
					ctmp = Color.FromArgb(Math.Min((color.R + ctmp.R) / 2, 255), Math.Min((color.G + ctmp.G) / 2, 255), Math.Min((color.B + ctmp.B) / 2, 255));
					image.SetPixel(y, x, ctmp);
				}
				this.progressBar.Value += y;
			}
			this.Invalidate();
			this.miEffet.Enabled = true;
			this.progressBar.Value = 0;
			EndEffet();
		}
		
		public void StartNiveauxDeGris(object obj, EventArgs ea) {
			if (Effet!=null)
			{
				Effet.Abort();
				Effet = null;
			}
			Effet = new System.Threading.Thread(new System.Threading.ThreadStart(NiveauxDeGris));
			Effet.Priority = System.Threading.ThreadPriority.Lowest;
			Effet.IsBackground = true;
			Effet.Start ();
			this.progressBar.Visible = true;
		}
		
		private void NiveauxDeGris() {
			BeginEffet();
			ctmp = new Color();
			int x;
			int y;
			int i;
			
			for(x=0; x<image.Height; x++)
			{
				for(y=0; y<image.Width; y++)
				{
					ctmp = image.GetPixel(y, x);
					i = (int)((ctmp.R + ctmp.G + ctmp.B) / 3);
					ctmp = Color.FromArgb(i, i, i);
					image.SetPixel(y, x, ctmp);
				}
				this.progressBar.Value +=y;
			}
			this.Invalidate();
			this.miEffet.Enabled = true;
			this.progressBar.Value = 0;
			EndEffet();
		}
		
		public void StartNoirEtBlanc(object obj, EventArgs ea) {
			if (Effet!=null)
			{
				Effet.Abort();
				Effet = null;
			}
			Effet = new System.Threading.Thread(new System.Threading.ThreadStart(NoirEtBlanc));
			Effet.Priority = System.Threading.ThreadPriority.Lowest;
			Effet.IsBackground = true;
			Effet.Start ();
			this.progressBar.Visible = true;
		}
		
		private void NoirEtBlanc() {
			BeginEffet();
			ctmp = new Color();
			int x;
			int y;
			int i;
			
			for(x=0; x<image.Height; x++)
			{
				for(y=0; y<image.Width; y++)
				{
					ctmp = image.GetPixel(y, x);
					i = (int)((ctmp.R + ctmp.G + ctmp.B) / 3);
					if(i < 128)
					{
						i = 0;
					}
					else
					{
						i = 255;
					}
					ctmp = Color.FromArgb(i, i, i);
					image.SetPixel(y, x, ctmp);
				}
				this.progressBar.Value += y;
			}
			this.Invalidate();
			this.miEffet.Enabled = true;
			this.progressBar.Value = 0;
			EndEffet();
		}
		
		private void Rotation90(object obj, EventArgs ea) {
			this.image.RotateFlip(RotateFlipType.Rotate90FlipNone);
			this.Invalidate();
		}
		
		private void Rotation180(object obj, EventArgs ea) {
			this.image.RotateFlip(RotateFlipType.Rotate180FlipNone);
			this.Invalidate();
		}
		
		private void Rotation270(object obj, EventArgs ea) {
			this.image.RotateFlip(RotateFlipType.Rotate270FlipNone);
			this.Invalidate();
		}
		
		private void FlipHB(object obj, EventArgs ea) {
			this.image.RotateFlip(RotateFlipType.RotateNoneFlipY);
			this.Invalidate();
		}
		
		private void FlipGD(object obj, EventArgs ea) {
			this.image.RotateFlip(RotateFlipType.RotateNoneFlipX);
			this.Invalidate();
		}
	}
}
