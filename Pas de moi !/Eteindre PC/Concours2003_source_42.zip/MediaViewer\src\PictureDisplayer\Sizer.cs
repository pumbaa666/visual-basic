// created on 02/06/2003 at 08:10
using System;
using System.Windows.Forms;

namespace PictureDisplayer {
	public class Sizer : System.Windows.Forms.Form
	{
		private Label lbllong;
		private Label lblhaut;
		
		public NumericUpDown txtlong;
		public NumericUpDown txthaut;
		
		private Button btn;
		
		public Sizer()
		{
			InitializeComponent();
			this.ClientSize = new System.Drawing.Size(this.btn.Right + 5, this.btn.Bottom + 5);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		}
		
		void InitializeComponent() {
			this.lbllong = new Label();
			this.lbllong.Parent = this;
			this.lbllong.Text = "Longueur :";
			this.lbllong.Location = new System.Drawing.Point(10, 10);
			
			this.lblhaut = new Label();
			this.lblhaut.Parent = this;
			this.lblhaut.Text = "Hauteur :";
			this.lblhaut.Location = new System.Drawing.Point(10, this.lbllong.Bottom + 10);
			
			this.txtlong = new NumericUpDown();
			this.txtlong.Parent = this;
			this.txtlong.Minimum = 0;
			this.txtlong.Maximum = 2147483647;
			this.txtlong.Location = new System.Drawing.Point(this.lbllong.Right + 5, 8);
			
			this.txthaut = new NumericUpDown();
			this.txthaut.Parent = this;
			this.txthaut.Minimum = 0;
			this.txthaut.Maximum = 2147483647;
			this.txthaut.Location = new System.Drawing.Point(this.lbllong.Right + 5, this.txtlong.Bottom + 8);
			
			this.btn = new Button();
			this.btn.Parent = this;
			this.btn.Text = "Ok";
			this.btn.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btn.FlatStyle = FlatStyle.System;
			this.btn.Location = new System.Drawing.Point(this.txthaut.Right - this.btn.Width, this.txthaut.Bottom + 8);
		}
	}
}
