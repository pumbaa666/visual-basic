using Microsoft.Win32;

using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;


namespace MediaViewer
{

	class MainForm : System.Windows.Forms.Form
	{
		ResourceManager rm = new ResourceManager("MediaViewerFilesIcons", Assembly.GetCallingAssembly());
		
		public const uint SHGFI_ICON				= 0x000000100;     // get icon
		public const uint SHGFI_LARGEICON			= 0x000000000;     // get large icon
		
		[DllImport("Shell32.dll")]
		public static extern int SHGetFileInfo( string pszPath, uint
			dwFileAttributes, ref SHFILEINFO psfi, uint cbfileInfo, uint uFlags);
		
		[ StructLayout( LayoutKind.Sequential ) ]
			public struct SHFILEINFO
		{
			public IntPtr hIcon;
			public int iIcon;
			public uint dwAttributes;
			[MarshalAs(UnmanagedType.LPStr, SizeConst=260)] public string szDisplayName;
			[MarshalAs(UnmanagedType.LPStr, SizeConst=80)] public string szTypeName;
		}
		
		private System.Threading.Thread Fill = null;
		
		
		PictureBox InfoPictureBox = new PictureBox();
		Label lblNomFichier = new Label();
		Label lblPathFichier = new Label();
		Label lblTailleFichier = new Label();
		
		ImageList DispimgList = new ImageList();
		ImageList FavImageimgList = new ImageList();
		ImageList FavMusiqueimgList = new ImageList();
		ImageList FavVideoimgList = new ImageList();
		ImageList ImageimgList = new ImageList();
		ImageList PlayListimgList = new ImageList();
		ImageList MusiqueimgList = new ImageList();
		ImageList VideoimgList = new ImageList();
		ImageList AutreimgList = new ImageList();
		
		ColumnHeader col;
		
		Panel panel;
		Panel panel2;
		Panel panelInfo;
		
		Splitter split;
		
		LinkLabel lblExplorateur;
		LinkLabel lblInformations;
		
		LinkLabel lblFavImages;
		LinkLabel lblFavMusiques;
		LinkLabel lblFavVideos;
		LinkLabel lblImages;
		LinkLabel lblPlayLists;
		LinkLabel lblMusiques;
		LinkLabel lblVideos;
		LinkLabel lblAutres;
		
		bool dirTreeViewVisible;
		bool InformationVisible;
		
		bool lvFavImageVisible;
		bool lvFavMusiqueVisible;
		bool lvFavVideoVisible;
		bool lvImageVisible;
		bool lvPlayListVisible;
		bool lvMusiqueVisible;
		bool lvVideoVisible;
		bool lvAutreVisible;
		
		string strDirectory;
		
		public RichListView lvFavImages;
		public RichListView lvFavMusiques;
		public RichListView lvFavVideos;
		RichListView lvImages;
		RichListView lvPlayLists;
		RichListView lvMusiques;
		RichListView lvVideos;
		RichListView lvAutres;
		
		ToolTip tooltip;
		
		int position;
		int position2;
		
		
		private System.Windows.Forms.DirectoryTreeView dirTreeView;
		
		public MainForm() {
			this.Text = "MediaViewer";
			
			
			this.ImageimgList.ImageSize = new Size(70, 70);
			this.PlayListimgList.ImageSize = new Size(32, 32);
			this.MusiqueimgList.ImageSize = new Size(32, 32);
			this.VideoimgList.ImageSize = new Size(32, 32);
			this.AutreimgList.ImageSize = new Size(32, 32);
			
			this.lvImageVisible = true;
			this.lvPlayListVisible = true;
			this.lvMusiqueVisible = true;
			this.lvVideoVisible = true;
			this.lvAutreVisible = true;
			
			//
			// Panel
			//
			this.panel = new System.Windows.Forms.Panel();
			this.panel.Parent = this;
			this.panel.BackColor = Color.AliceBlue;
			this.panel.Dock = DockStyle.Fill;
			//
			// Splitter
			//
			this.split = new System.Windows.Forms.Splitter();
			this.split.BackColor = System.Drawing.Color.CornflowerBlue;
			this.split.Parent = this;
			this.split.Dock = DockStyle.Right;
			this.split.Enabled = false;
			//
			// Panel2
			//
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel2.Dock = DockStyle.Right;
			this.panel2.BackColor = System.Drawing.Color.White;
			this.panel2.Parent = this;
			this.panel2.BackColor = Color.AliceBlue;
			//
			// PanelInfo
			//
			this.panelInfo = new System.Windows.Forms.Panel();
			this.panelInfo.Parent = this.panel;
			this.panelInfo.BackColor = Color.White;
			//
			// lblInformations
			//
			this.lblInformations = new System.Windows.Forms.LinkLabel();
			this.lblInformations.Parent = this.panel;
			this.lblInformations.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblInformations.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblInformations.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblInformations.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblInformations.Text = "Infos Fichier";
			this.lblInformations.Name = "Informations";
			this.lblInformations.Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold);
			this.lblInformations.Width = this.panel.Width;
			//
			// lblExplorateur
			//
			this.lblExplorateur = new System.Windows.Forms.LinkLabel();
			this.lblExplorateur.Parent = this.panel;
			this.lblExplorateur.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblExplorateur.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblExplorateur.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblExplorateur.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblExplorateur.Text = "Explorateur";
			this.lblExplorateur.Name = "Explorateur";
			this.lblExplorateur.Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold);
			this.lblExplorateur.Width = this.panel.Width;
			//
			// lblFavImages
			//
			this.lblFavImages = new System.Windows.Forms.LinkLabel();
			this.lblFavImages.Parent = this.panel2;
			this.lblFavImages.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblFavImages.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavImages.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavImages.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblFavImages.Text = "Images Favorites";
			this.lblFavImages.Name = "Images Favorites";
			this.lblFavImages.Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold);
			this.lblFavImages.Width = this.panel.Width;
			//
			// lblFavMusiques
			//
			this.lblFavMusiques = new System.Windows.Forms.LinkLabel();
			this.lblFavMusiques.Parent = this.panel2;
			this.lblFavMusiques.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblFavMusiques.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavMusiques.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavMusiques.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblFavMusiques.Text = "Musiques Favorites";
			this.lblFavMusiques.Name = "Musiques Favorites";
			this.lblFavMusiques.Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold);
			this.lblFavMusiques.Width = this.panel.Width;
			//
			// lblFavVideos
			//
			this.lblFavVideos = new System.Windows.Forms.LinkLabel();
			this.lblFavVideos.Parent = this.panel2;
			this.lblFavVideos.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblFavVideos.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavVideos.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblFavVideos.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblFavVideos.Text = "Videos Favorites";
			this.lblFavVideos.Name = "Videos Favorites";
			this.lblFavVideos.Font = new System.Drawing.Font("Arial", 13, System.Drawing.FontStyle.Bold);
			this.lblFavVideos.Width = this.panel.Width;
			//
			// lblImages
			//
			this.lblImages = new System.Windows.Forms.LinkLabel();
			this.lblImages.Parent = this.panel2;
			this.lblImages.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblImages.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblImages.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblImages.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblImages.Text = "Images";
			this.lblImages.Name = "Images";
			this.lblImages.Font = new System.Drawing.Font("Arial", 15, System.Drawing.FontStyle.Bold);
			this.lblImages.Width = this.panel.Width;
			//
			// lblPlayLists
			//
			this.lblPlayLists = new System.Windows.Forms.LinkLabel();
			this.lblPlayLists.Parent = this.panel2;
			this.lblPlayLists.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblPlayLists.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblPlayLists.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblPlayLists.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblPlayLists.Text = "PlayLists";
			this.lblPlayLists.Name = "PlayLists";
			this.lblPlayLists.Font = new System.Drawing.Font("Arial", 15, System.Drawing.FontStyle.Bold);
			this.lblPlayLists.Width = this.panel.Width;
			//
			// lblMusiques
			//
			this.lblMusiques = new System.Windows.Forms.LinkLabel();
			this.lblMusiques.Parent = this.panel2;
			this.lblMusiques.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblMusiques.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblMusiques.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblMusiques.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblMusiques.Text = "Musiques";
			this.lblMusiques.Name = "Musiques";
			this.lblMusiques.Font = new System.Drawing.Font("Arial", 15, System.Drawing.FontStyle.Bold);
			this.lblMusiques.Width = this.panel.Width;
			//
			// lblVideos
			//
			this.lblVideos = new System.Windows.Forms.LinkLabel();
			this.lblVideos.Parent = this.panel2;
			this.lblVideos.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblVideos.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblVideos.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblVideos.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblVideos.Text = "Videos";
			this.lblVideos.Name = "Videos";
			this.lblVideos.Font = new System.Drawing.Font("Arial", 15, System.Drawing.FontStyle.Bold);
			this.lblVideos.Width = this.panel.Width;
			//
			// lblAutres
			//
			this.lblAutres = new System.Windows.Forms.LinkLabel();
			this.lblAutres.Parent = this.panel2;
			this.lblAutres.BackColor = System.Drawing.Color.CornflowerBlue;
			this.lblAutres.ActiveLinkColor = System.Drawing.Color.AliceBlue;
			this.lblAutres.LinkColor = System.Drawing.Color.AliceBlue;
			this.lblAutres.LinkClicked += new LinkLabelLinkClickedEventHandler(lblOnClick);
			this.lblAutres.Text = "Autres";
			this.lblAutres.Name = "Autres";
			this.lblAutres.Font = new System.Drawing.Font("Arial", 15, System.Drawing.FontStyle.Bold);
			
			this.col = new ColumnHeader();
			this.col.Text = "Nom";
			this.col.Width = 1500;
			this.lblAutres.Width = this.panel.Width;
			//
			// lvFavImages
			//
			this.lvFavImages = new System.Windows.Forms.RichListView("img");
			this.lvFavImages.Parent = this.panel2;
			this.lvFavImages.farfouilleur = true;
			this.lvFavImages.View = View.Details;
			this.lvFavImages.Columns.Add(col);
			this.lvFavImages.BackColor = Color.White;
			this.lvFavImages.SmallImageList = FavImageimgList;
			this.lvFavImages.LargeImageList = FavImageimgList;
			
			this.col = new ColumnHeader();
			this.col.Text = "Nom";
			this.col.Width = 1500;
			this.lblAutres.Width = this.panel.Width;
			//
			// lvFavMusiques
			//
			this.lvFavMusiques = new System.Windows.Forms.RichListView("mus");
			this.lvFavMusiques.Parent = this.panel2;
			this.lvFavMusiques.farfouilleur = true;
			this.lvFavMusiques.View = View.Details;
			this.lvFavMusiques.Columns.Add(col);
			this.lvFavMusiques.SmallImageList = FavMusiqueimgList;
			this.lvFavMusiques.LargeImageList = FavMusiqueimgList;
			
			this.col = new ColumnHeader();
			this.col.Text = "Nom";
			this.col.Width = 1500;
			this.lblAutres.Width = this.panel.Width;
			//
			// lvFavVideos
			//
			this.lvFavVideos = new System.Windows.Forms.RichListView("vid");
			this.lvFavVideos.Parent = this.panel2;
			this.lvFavVideos.farfouilleur = true;
			this.lvFavVideos.View = View.Details;
			this.lvFavVideos.Columns.Add(col);
			this.lvFavVideos.SmallImageList = FavVideoimgList;
			this.lvFavVideos.LargeImageList = FavVideoimgList;
			//
			// lvImages
			//
			this.lvImages = new System.Windows.Forms.RichListView("img");
			this.lvImages.FileInfoPossible += new FileInfoPossibleEventHandler(DisplayFileInfo);
			this.lvImages.LoadFav += new LoadFavEventHandler(LoadFavorites);
			this.lvImages.Parent = this.panel2;
			this.lvImages.View = View.LargeIcon;
			this.lvImages.SmallImageList = ImageimgList;
			this.lvImages.LargeImageList = ImageimgList;
			//
			// lvPlayLists
			//
			this.lvPlayLists = new System.Windows.Forms.RichListView("pls");
			this.lvPlayLists.FileInfoPossible += new FileInfoPossibleEventHandler(DisplayFileInfo);
			this.lvPlayLists.LoadFav += new LoadFavEventHandler(LoadFavorites);
			this.lvPlayLists.Parent = this.panel2;
			this.lvPlayLists.View = View.LargeIcon;
			this.lvPlayLists.SmallImageList = PlayListimgList;
			this.lvPlayLists.LargeImageList = PlayListimgList;
			//
			// lvMusiques
			//
			this.lvMusiques = new System.Windows.Forms.RichListView("mus");
			this.lvMusiques.FileInfoPossible += new FileInfoPossibleEventHandler(DisplayFileInfo);
			this.lvMusiques.LoadFav += new LoadFavEventHandler(LoadFavorites);
			this.lvMusiques.Parent = this.panel2;
			this.lvMusiques.View = View.LargeIcon;
			this.lvMusiques.SmallImageList = MusiqueimgList;
			this.lvMusiques.LargeImageList = MusiqueimgList;
			//
			// lvVideos
			//
			this.lvVideos = new System.Windows.Forms.RichListView("vid");
			this.lvVideos.FileInfoPossible += new FileInfoPossibleEventHandler(DisplayFileInfo);
			this.lvVideos.LoadFav += new LoadFavEventHandler(LoadFavorites);
			this.lvVideos.Parent = this.panel2;
			this.lvVideos.View = View.LargeIcon;
			this.lvVideos.SmallImageList = VideoimgList;
			this.lvVideos.LargeImageList = VideoimgList;
			//
			// lvAutres
			//
			this.lvAutres = new System.Windows.Forms.RichListView("aut");
			this.lvAutres.FileInfoPossible += new FileInfoPossibleEventHandler(DisplayFileInfo);
			this.lvAutres.Parent = this.panel2;
			this.lvAutres.View = View.LargeIcon;
			this.lvAutres.SmallImageList = AutreimgList;
			this.lvAutres.LargeImageList = AutreimgList;
			//
			// dirTreeView
			//
			this.dirTreeView = new System.Windows.Forms.DirectoryTreeView();
			this.dirTreeView.Parent = this.panel;
			this.dirTreeView.BackColor = System.Drawing.Color.FromArgb(250, 250, 250);
			this.dirTreeView.AfterSelect += new TreeViewEventHandler(StartFillListView);
			
			this.tooltip = new ToolTip();
			this.tooltip.SetToolTip(this.lblImages, "Enrouler/derouler la liste des images");
			this.tooltip.SetToolTip(this.lblPlayLists, "Enrouler/derouler la liste des Playlists");
			this.tooltip.SetToolTip(this.lblMusiques, "Enrouler/derouler la liste des morceaux");
			this.tooltip.SetToolTip(this.lblVideos, "Enrouler/derouler la liste des videos");
			this.tooltip.SetToolTip(this.lblAutres, "Enrouler/derouler la liste des fichiers divers");
			this.tooltip.SetToolTip(this.lblFavImages, "Afficher/Masquer vos images favorites");
			this.tooltip.SetToolTip(this.lblFavMusiques, "Afficher/Masquer vos sons preferes");
			this.tooltip.SetToolTip(this.lblFavVideos, "Afficher/Masquer vos video favorites");
			
			InitializePreferences();
			InitializeMenus();
			InitializeFavFiles();
		}
		
		[STAThread]
		public static void Main(string[] args) {
			MainForm mf = new MainForm();
			mf.ClientSize = new Size(700, 500);
			Application.Run(mf);
		}
		
		protected override void OnResize(EventArgs ea) {
			base.OnResize(ea);
			this.panel2.Width = this.ClientSize.Width - 250;
			this.ReDraw();
		}
		
		protected override void OnLoad(EventArgs ea) {
			base.OnLoad(ea);
			this.OnResize(ea);
		}
		protected override void OnClosed(EventArgs ea) {
			base.OnClosed(ea);
			
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey("Software\\MediaViewer", true);
			regkey.SetValue("Information", this.InformationVisible.ToString());
			regkey.SetValue("dirTreeView", this.dirTreeViewVisible.ToString());
			regkey.SetValue("lvFavImage", this.lvFavImageVisible.ToString());
			regkey.SetValue("lvFavMusique", this.lvFavMusiqueVisible.ToString());
			regkey.SetValue("lvFavVideo", this.lvFavVideoVisible.ToString());
			regkey.SetValue("lvImage", this.lvImageVisible.ToString());
			regkey.SetValue("lvPlayList", this.lvPlayListVisible.ToString());
			regkey.SetValue("lvMusique", this.lvMusiqueVisible.ToString());
			regkey.SetValue("lvVideo", this.lvVideoVisible.ToString());
			regkey.SetValue("lvAutre", this.lvAutreVisible.ToString());
		}
		
		private void DisplayFileInfo(object obj) {
			ListViewItem lvi = (ListViewItem)obj;
			string path = Path.Combine(this.dirTreeView.SelectedNode.FullPath, lvi.Text);
			if(IsPicture(path))
			{
				DisplayPictureInfo(path, lvi);
			}
			else
				{
					DisplayInfo(path, lvi);
				}
		}
		
		private void DisplayPictureInfo(string path, ListViewItem lvi) {
			System.GC.Collect();
			System.GC.WaitForPendingFinalizers();
			
			FileInfo fi = new FileInfo(path);
			
			Image image = Image.FromFile(path);
			this.InfoPictureBox.Parent = this.panelInfo;
			this.InfoPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
			this.InfoPictureBox.Image = image;
			if(image.Width <= this.panelInfo.Width - 17)
			{
				this.InfoPictureBox.Width = image.Width;
				this.InfoPictureBox.Height = image.Height;
			}
			else
				{
					float proportion = image.Width / this.panelInfo.Width;
					this.InfoPictureBox.Width = Math.Min((int)(image.Width / (proportion + 1)), this.panel.Width - 34);
					this.InfoPictureBox.Height = (int)(image.Height / (proportion + 1));
				}
			this.lblNomFichier.AutoSize = true;
			this.lblNomFichier.Parent = this.panelInfo;
			this.lblNomFichier.Text = "Nom du fichier : " + lvi.Text;
			this.tooltip.SetToolTip(this.lblNomFichier, this.lblNomFichier.Text);
			this.lblNomFichier.Location = new System.Drawing.Point(0, this.InfoPictureBox.Bottom + 5);
			
			this.lblPathFichier.AutoSize = true;
			this.lblPathFichier.Parent = this.panelInfo;
			this.lblPathFichier.Text = "Dans le dossier : " + this.dirTreeView.SelectedNode.FullPath;
			this.tooltip.SetToolTip(this.lblPathFichier, this.lblPathFichier.Text);
			this.lblPathFichier.Location = new System.Drawing.Point(0, this.lblNomFichier.Bottom + 5);
			
			int taille;
			int o;
			int ko;
			int mo;
			int go;
			string strtaille = "";
			
			taille = (int)fi.Length;
			o = taille % 1024;
			taille = (taille - o) / 1024;
			ko = taille % 1024;
			taille = (taille - ko) / 1024;
			mo = taille %1024;
			taille = (taille - mo) / 1024;
			go = taille % 1024;
			
			if(go != 0)
				strtaille += go.ToString() + " Go";
			if(mo != 0)
				strtaille += "  " + mo.ToString() + " Mo";
			if(ko != 0)
				strtaille += "  " + ko.ToString() + " Ko";
			if(o != 0)
				strtaille += "  " + o.ToString() + " Octets";
			strtaille += ".";
			
			this.lblTailleFichier.AutoSize = true;
			this.lblTailleFichier.Parent = this.panelInfo;
			this.lblTailleFichier.Text = "Taille : " + strtaille;
			this.lblTailleFichier.Location = new System.Drawing.Point(0, this.lblPathFichier.Bottom + 5);
		}
		
		private void DisplayInfo(string path, ListViewItem lvi) {
			System.GC.Collect();
			System.GC.WaitForPendingFinalizers();
			
			FileInfo fi = new FileInfo(path);
			
			this.DispimgList.Images.Clear();
			this.DispimgList.ImageSize = new Size(48, 48);
			this.InfoPictureBox.Parent = this.panelInfo;
			this.InfoPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
			this.DispimgList.Images.Add(getLargeIcon(path));
			this.InfoPictureBox.Image = this.DispimgList.Images[0];
			this.InfoPictureBox.Size = new Size(72, 72);
			
			this.lblNomFichier.AutoSize = true;
			this.lblNomFichier.Parent = this.panelInfo;
			this.lblNomFichier.Text = "Nom du fichier : " + lvi.Text;
			this.tooltip.SetToolTip(this.lblNomFichier, this.lblNomFichier.Text);
			this.lblNomFichier.Location = new System.Drawing.Point(0, this.InfoPictureBox.Bottom + 10);
			
			this.lblPathFichier.AutoSize = true;
			this.lblPathFichier.Parent = this.panelInfo;
			this.lblPathFichier.Text = "Dans le dossier : " + this.dirTreeView.SelectedNode.FullPath;
			this.tooltip.SetToolTip(this.lblPathFichier, this.lblPathFichier.Text);
			this.lblPathFichier.Location = new System.Drawing.Point(0, this.lblNomFichier.Bottom + 10);
			
			int taille;
			int o;
			int ko;
			int mo;
			int go;
			string strtaille = "";
			
			taille = (int)fi.Length;
			o = taille % 1024;
			taille = (taille - o) / 1024;
			ko = taille % 1024;
			taille = (taille - ko) / 1024;
			mo = taille %1024;
			taille = (taille - mo) / 1024;
			go = taille % 1024;
			
			if(go != 0)
				strtaille += go.ToString() + " Go";
			if(mo != 0)
				strtaille += "  " + mo.ToString() + " Mo";
			if(ko != 0)
				strtaille += "  " + ko.ToString() + " Ko";
			if(o != 0)
				strtaille += "  " + o.ToString() + " Octets";
			strtaille += ".";
			
			this.lblTailleFichier.AutoSize = true;
			this.lblTailleFichier.Parent = this.panelInfo;
			this.lblTailleFichier.Text = "Taille : " + strtaille;
			this.lblTailleFichier.Location = new System.Drawing.Point(0, this.lblPathFichier.Bottom + 5);
		}
		
		private void ReDraw() {
			this.panel.AutoScroll = false;
			this.position2 = 0;
			
			this.lblInformations.Width = this.panel.Width - 17;
			this.lblInformations.Location = new System.Drawing.Point(0, this.position2);
			this.position2 += this.lblInformations.Height;
			if(this.InformationVisible)
			{
				this.panelInfo.Height = 300;
				this.panelInfo.Width = this.panel.Width - 17;
				this.panelInfo.Location = new System.Drawing.Point(0, this.position2);
				this.position2 += 300;
			}
			else
				{
					this.panelInfo.Visible = false;
				}
			this.position2 += this.lblInformations.Height;
			
			
			this.lblExplorateur.Width = this.panel.Width - 17;
			this.lblExplorateur.Location = new System.Drawing.Point(0, this.position2);
			this.position2 += this.lblExplorateur.Height;
			if(this.dirTreeViewVisible)
			{
				this.dirTreeView.Height = 600;
				this.dirTreeView.Width = this.panel.Width - 17;
				this.dirTreeView.Location = new System.Drawing.Point(0, this.position2);
			}
			else
				{
					this.dirTreeView.Visible = false;
				}
			
			
			this.panel.AutoScroll = true;
			
			
			
			
			this.panel2.AutoScroll = false;
			this.position = 0;
			
			this.lblFavImages.Width = (int)((this.panel2.Width / 3) - 17);
			this.lblFavMusiques.Width = (int)((this.panel2.Width / 3) - 17);
			this.lblFavVideos.Width = (int)((this.panel2.Width / 3) - 17);
			
			this.lblFavImages.Location = new System.Drawing.Point(0, this.position);
			this.lblFavMusiques.Location = new System.Drawing.Point(this.lblFavImages.Width + 17, this.position);
			this.lblFavVideos.Location = new System.Drawing.Point(this.lblFavMusiques.Width  + this.lblFavImages.Width + 34, this.position);
			
			this.position += this.lblFavImages.Height;
			
			if(lvFavImageVisible)
			{
				this.lvFavImages.Height = 300;
				this.lvFavImages.Width = (int)((this.panel2.Width / 3) - 17);
				this.lvFavImages.Location = new System.Drawing.Point(0, this.position);
			}
			else
				{
					this.lvFavImages.Visible = false;
				}
			if(lvFavMusiqueVisible)
			{
				this.lvFavMusiques.Height = 300;
				this.lvFavMusiques.Width = (int)((this.panel2.Width / 3) - 17);
				this.lvFavMusiques.Location = new System.Drawing.Point(this.lblFavImages.Width + 17, this.position);
			}
			else
				{
					this.lvFavMusiques.Visible = false;
				}
			if(lvFavVideoVisible)
			{
				this.lvFavVideos.Height = 300;
				this.lvFavVideos.Width = (int)((this.panel2.Width / 3) - 17);
				this.lvFavVideos.Location = new System.Drawing.Point(this.lblFavMusiques.Width  + this.lblFavImages.Width + 34, this.position);
			}
			else
				{
					this.lvFavVideos.Visible = false;
				}
			
			
			if(lvFavImageVisible || lvFavMusiqueVisible || lvFavVideoVisible)
			{
				this.position += 300 + this.lblImages.Height;
			}
			else
				{
					this.position += this.lblImages.Height;
				}
			
			
			this.lblImages.Width = this.panel2.Width - 17;
			this.lblImages.Location = new System.Drawing.Point(0, this.position);
			this.position += this.lblImages.Height;
			
			if(lvImageVisible)
			{
				this.lvImages.Height = 300;
				this.lvImages.Width = this.panel2.Width - 17;
				this.lvImages.Location = new System.Drawing.Point(0, this.position);
				this.position += 300 + this.lblImages.Height;
			}
			else
				{
					this.lvImages.Visible = false;
					this.position += this.lblImages.Height;
				}
			
			this.lblPlayLists.Width = this.panel2.Width - 17;
			this.lblPlayLists.Location = new System.Drawing.Point(0, this.position);
			this.position += this.lblImages.Height;
			
			if(lvPlayListVisible)
			{
				this.lvPlayLists.Height = 80;
				this.lvPlayLists.Width = this.panel2.Width - 17;
				this.lvPlayLists.Location = new System.Drawing.Point(0, this.position);
				this.position += 80 + this.lblPlayLists.Height;
			}
			else
				{
					this.lvPlayLists.Visible = false;
					this.position += this.lblPlayLists.Height;
				}
				
			this.lblMusiques.Width = this.panel2.Width - 17;
			this.lblMusiques.Location = new System.Drawing.Point(0, this.position);
			this.position += this.lblImages.Height;
			
			if(lvMusiqueVisible)
			{
				this.lvMusiques.Height = 200;
				this.lvMusiques.Width = this.panel2.Width - 17;
				this.lvMusiques.Location = new System.Drawing.Point(0, this.position);
				this.position += 200 + this.lblMusiques.Height;
			}
			else
				{
					this.lvMusiques.Visible = false;
					this.position += this.lblMusiques.Height;
				}
			
			this.lblVideos.Width = this.panel2.Width - 17;
			this.lblVideos.Location = new System.Drawing.Point(0, this.position);
			this.position += this.lblImages.Height;
			
			if(lvVideoVisible)
			{
				this.lvVideos.Height = 200;
				this.lvVideos.Width = this.panel2.Width - 17;
				this.lvVideos.Location = new System.Drawing.Point(0, this.position);
				this.position += 200 + this.lblVideos.Height;
			}
			else
				{
					this.lvVideos.Visible = false;
					this.position += this.lblVideos.Height;
				}
			
			this.lblAutres.Width = this.panel2.Width - 17;
			this.lblAutres.Location = new System.Drawing.Point(0, this.position);
			this.position += this.lblImages.Height;
			
			if(lvAutreVisible)
			{
				this.lvAutres.Height = 400;
				this.lvAutres.Width = this.panel2.Width - 17;
				this.lvAutres.Location = new System.Drawing.Point(0, this.position);
				this.position += 400 + this.lblAutres.Height;
			}
			else
				{
					this.lvAutres.Visible = false;
					this.position += this.lblAutres.Height;
				}
			this.panel2.AutoScroll = true;
		}
		
		private void lblOnClick(object obj,  LinkLabelLinkClickedEventArgs mea) {
			LinkLabel lnk = (LinkLabel)obj;
			switch(lnk.Name)
			{
				case "Informations":	if(this.InformationVisible)
										{
											this.panelInfo.Visible = false;
											this.InformationVisible = false;
										}
										else
											{
												this.panelInfo.Visible = true;
												this.InformationVisible = true;
											}
										break;
				case "Explorateur":		if(this.dirTreeViewVisible)
										{
											this.dirTreeView.Visible = false;
											this.dirTreeViewVisible = false;
										}
										else
											{
												this.dirTreeView.Visible = true;
												this.dirTreeViewVisible = true;
											}
										break;
				case "Images Favorites":if(this.lvFavImageVisible)
										{
											this.lvFavImages.Visible = false;
											this.lvFavImageVisible = false;
										}
										else
											{
												this.lvFavImages.Visible = true;
												this.lvFavImageVisible = true;
											}
										break;
				case "Musiques Favorites":if(this.lvFavMusiqueVisible)
										{
											this.lvFavMusiques.Visible = false;
											this.lvFavMusiqueVisible = false;
										}
										else
											{
												this.lvFavMusiques.Visible = true;
												this.lvFavMusiqueVisible = true;
											}
										break;
				case "Videos Favorites":if(this.lvFavVideoVisible)
										{
											this.lvFavVideos.Visible = false;
											this.lvFavVideoVisible = false;
										}
										else
											{
												this.lvFavVideos.Visible = true;
												this.lvFavVideoVisible = true;
											}
										break;
				case "Images":		if(this.lvImageVisible)
									{
										this.lvImages.Visible = false;
										this.lvImageVisible = false;
									}
									else
										{
											this.lvImages.Visible = true;
											this.lvImageVisible = true;
										}
									break;
				case "PlayLists":	if(this.lvPlayListVisible)
									{
										this.lvPlayLists.Visible = false;
										this.lvPlayListVisible = false;
									}
									else
										{
											this.lvPlayLists.Visible = true;
											this.lvPlayListVisible = true;
										}
									break;
				case "Musiques":	if(this.lvMusiqueVisible)
									{
										this.lvMusiques.Visible = false;
										this.lvMusiqueVisible = false;
									}
									else
										{
											this.lvMusiques.Visible = true;
											this.lvMusiqueVisible = true;
										}
									break;
				case "Videos":		if(this.lvVideoVisible)
										{
											this.lvVideos.Visible = false;
											this.lvVideoVisible = false;
										}
										else
											{
												this.lvVideos.Visible = true;
												this.lvVideoVisible = true;
											}
										break;
				case "Autres":		if(this.lvAutreVisible)
										{
											this.lvAutres.Visible = false;
											this.lvAutreVisible = false;
										}
										else
											{
												this.lvAutres.Visible = true;
												this.lvAutreVisible = true;
											}
										break;
				default : break;
			}
			this.ReDraw();
		}
		
		public void StartFillListView(object obj, TreeViewEventArgs tvea) {
			this.strDirectory = tvea.Node.FullPath;
			if (Fill!=null)
			{
				Fill.Abort();
				Fill = null;
			}
			Fill = new System.Threading.Thread(new System.Threading.ThreadStart(FillListView));
			Fill.Priority = System.Threading.ThreadPriority.Lowest;
			Fill.IsBackground = true;
			Fill.Start();
		}
		
		private void FillListView() {
			System.GC.Collect();
			System.GC.WaitForPendingFinalizers();
			
			string fullpath;
			this.lvImages.strDir = strDirectory;
			this.lvImages.lviInfo = null;
			this.lvPlayLists.strDir = strDirectory;
			this.lvPlayLists.lviInfo = null;
			this.lvMusiques.strDir = strDirectory;
			this.lvMusiques.lviInfo = null;
			this.lvVideos.strDir = strDirectory;
			this.lvVideos.lviInfo = null;
			this.lvAutres.strDir = strDirectory;
			
			Image image;
			
			string[] fichiers;
			try
			{
				fichiers = System.IO.Directory.GetFiles(this.strDirectory);
			}
			catch
			{
				return;
			}
			
			int img = 0;
			int pls = 0;
			int mus = 0;
			int vid = 0;
			int aut = 0;
			this.ImageimgList.Images.Clear();
			this.lvImages.Items.Clear();
			this.lblImages.Text = "Images";
			this.PlayListimgList.Images.Clear();
			this.lvPlayLists.Items.Clear();
			this.lblPlayLists.Text = "PlayLists";
			this.MusiqueimgList.Images.Clear();
			this.lvMusiques.Items.Clear();
			this.lblMusiques.Text = "Musiques";
			this.VideoimgList.Images.Clear();
			this.lvVideos.Items.Clear();
			this.lblVideos.Text = "Videos";
			this.AutreimgList.Images.Clear();
			this.lvAutres.Items.Clear();
			this.lblAutres.Text = "Autres";
			
			foreach(string s in fichiers)
			{
				System.IO.FileInfo fInfo = new System.IO.FileInfo( s );
				
				
				fullpath = s;
				
				Icon ico = getLargeIcon(fullpath);
				
				if((fInfo.Attributes & FileAttributes.System) != 0)
				{
					continue;
				}
				
				if(IsPicture(fullpath))
				{
					img++;
					
					image = Image.FromFile(fullpath);
					image = image.GetThumbnailImage(70, 70, null, (IntPtr)0);
					this.ImageimgList.Images.Add(image);
					this.lvImages.Items.Add(fInfo.Name, this.ImageimgList.Images.Count - 1);
					this.lblImages.Text = "Images - " + img.ToString();
				}
				else if(IsPlayList(fullpath))
				{
					pls++;
					try
					{
						
						ListViewItem lvi = new ListViewItem();
						this.lvPlayLists.LargeImageList.Images.Add (ico);
						lvi.ImageIndex = this.lvPlayLists.LargeImageList.Images.Count - 1;
						lvi.Text = fInfo.Name;
						
						this.lvPlayLists.Items.Add( lvi );
					}
					catch(Exception e)
					{
						MessageBox.Show(e.ToString());
						continue;
					}
					this.lblPlayLists.Text = "PlayLists - " + pls.ToString();
				}
				else if(IsMusique(fullpath))
				{
					mus++;
					try
					{
						ListViewItem lvi = new ListViewItem();
						this.lvMusiques.LargeImageList.Images.Add (ico);
						lvi.ImageIndex = this.lvMusiques.LargeImageList.Images.Count - 1;
						lvi.Text = fInfo.Name;
						
						this.lvMusiques.Items.Add(lvi);
					}
					catch(Exception e)
					{
						MessageBox.Show(e.ToString());
						continue;
					}
					this.lblMusiques.Text = "Musiques - " + mus.ToString();
				}
				else if(IsVideo(fullpath))
				{
					vid++;
					try
					{
						ListViewItem lvi = new ListViewItem();
						this.lvVideos.LargeImageList.Images.Add (ico);
						lvi.ImageIndex = this.lvVideos.LargeImageList.Images.Count - 1;
						lvi.Text = fInfo.Name;
						
						this.lvVideos.Items.Add(lvi);
					}
					catch(Exception e)
					{
						MessageBox.Show(e.ToString());
						continue;
					}
					this.lblVideos.Text = "Videos - " + vid.ToString();
				}
				else
					{
						aut++;
						try
						{
							ListViewItem lvi = new ListViewItem();
							this.lvAutres.LargeImageList.Images.Add (ico);
							lvi.ImageIndex = this.lvAutres.LargeImageList.Images.Count - 1;
							lvi.Text = fInfo.Name;
							
							this.lvAutres.Items.Add(lvi);
						}
						catch(Exception e)
						{
							MessageBox.Show(e.ToString());
							continue;
						}
						this.lblAutres.Text = "Autres - " + aut.ToString();
					}
			}
		}
		
		private bool IsPicture(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".JPG") || path.EndsWith(".JPEG") || path.EndsWith(".BMP") || path.EndsWith(".GIF") || path.EndsWith(".PNG") || path.EndsWith(".ICO"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsPlayList(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".M3U") ||path.EndsWith(".PLS"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsMusique(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".MP3") || path.EndsWith(".WAV") || path.EndsWith(".OGG") || path.EndsWith(".WMA"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private bool IsVideo(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".AVI") || path.EndsWith(".MPEG") || path.EndsWith(".MPG") || path.EndsWith(".MOV") ||path.EndsWith(".VOB"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private Icon getLargeIcon( string path ) {
			if(path.Substring(2, 2) == "\\\\")
				{
					path = path.Remove(2, 1);
				}
			SHFILEINFO info = new SHFILEINFO();
			SHGetFileInfo( path, 0, ref info, (uint) Marshal.SizeOf(info), SHGFI_ICON | SHGFI_LARGEICON);
			
			Icon ico = Icon.FromHandle( info.hIcon );
			return ico;
		}
		
		private void InitializePreferences() {
			RegistryKey regkey = Registry.CurrentUser.OpenSubKey("Software\\MediaViewer");
			
			if(regkey != null)
			{
				LoadRegistryInfo(regkey);
				regkey.Close();
			}
			else
				{
					regkey = Registry.CurrentUser.CreateSubKey("Software\\MediaViewer");
					regkey.SetValue("Information", "False");
					regkey.SetValue("dirTreeView", "False");
					regkey.SetValue("lvFavImage", "False");
					regkey.SetValue("lvFavMusique", "False");
					regkey.SetValue("lvFavVideo", "False");
					regkey.SetValue("lvImage", "False");
					regkey.SetValue("lvPlayList", "False");
					regkey.SetValue("lvMusique", "False");
					regkey.SetValue("lvVideo", "False");
					regkey.SetValue("lvAutre", "False");
				}
		}
		
		private void LoadRegistryInfo(RegistryKey regkey) {
			try
			{
				
				if(regkey.GetValue("Information").ToString() == "True")
				{
					this.InformationVisible = true;
				}
				else
					{
						this.InformationVisible = false;
					}
				if(regkey.GetValue("dirTreeView").ToString() == "True")
				{
					this.dirTreeViewVisible = true;
				}
				else
					{
						this.dirTreeViewVisible = false;
					}
				if(regkey.GetValue("lvFavImage").ToString() == "True")
				{
					this.lvFavImageVisible = true;
				}
				else
					{
						this.lvFavImageVisible = false;
					}
				if(regkey.GetValue("lvFavMusique").ToString() == "True")
				{
					this.lvFavMusiqueVisible = true;
				}
				else
					{
						this.lvFavMusiqueVisible = false;
					}
				if(regkey.GetValue("lvFavVideo").ToString() == "True")
				{
					this.lvFavVideoVisible = true;
				}
				else
					{
						this.lvFavVideoVisible = false;
					}
				if(regkey.GetValue("lvImage").ToString() == "True")
				{
				   this.lvImageVisible = true;
				}
				else
					{
						this.lvImageVisible = false;
					}
				if(regkey.GetValue("lvPlayList").ToString() == "True")
				{
				   this.lvPlayListVisible = true;
				}
				else
					{
						this.lvPlayListVisible = false;
					}
				if(regkey.GetValue("lvMusique").ToString() == "True")
				{
				   this.lvMusiqueVisible = true;
				}
				else
					{
						this.lvMusiqueVisible = false;
					}
				if(regkey.GetValue("lvVideo").ToString() == "True")
				{
				   this.lvVideoVisible = true;
				}
				else
					{
						this.lvVideoVisible = false;
					}
				if(regkey.GetValue("lvAutre").ToString() == "True")
				{
				   this.lvAutreVisible = true;
				}
				else
					{
						this.lvAutreVisible = false;
					}
			}
			catch
			{
				MessageBox.Show("Les preferences ont ete endommagee, la configuration par defaut va etre retablie", "MediaViewer");
				Registry.CurrentUser.DeleteSubKey("Software\\MediaViewer");
				
				InitializePreferences();
			}
		}
		
		private void InitializeMenus() {
			this.Menu = new MainMenu();
			
			MenuItem miFichier = new MenuItem();
			miFichier.Text = "&Fichier";
			MenuItem miRecherche = new MenuItem();
			miRecherche.Text = "&Recherche";
			MenuItem miDiapo = new MenuItem();
			miDiapo.Text = "&Diapo";
			MenuItem miAlbum = new MenuItem();
			miAlbum.Text = "Album";
			MenuItem miOptions = new MenuItem();
			miOptions.Text = "&Options";
			
			RichMenuItem miQuitter = new RichMenuItem();
			miQuitter.Text = "&Quitter";
			miQuitter.Shortcut = Shortcut.AltF4;
			miQuitter.Click += new EventHandler(Quitter);
			
			RichMenuItem miRechercheImage = new RichMenuItem();
			miRechercheImage.Text = "Rechercher les images";
			miRechercheImage.Click += new EventHandler(Recherche);
			RichMenuItem miRechercheSon = new RichMenuItem();
			miRechercheSon.Text = "Rechercher les sons";
			miRechercheSon.Click += new EventHandler(Recherche);
			RichMenuItem miRechercheVideo = new RichMenuItem();
			miRechercheVideo.Text = "Rechercher les videos";
			miRechercheVideo.Click += new EventHandler(Recherche);
			
			RichMenuItem miDiapoCourant = new RichMenuItem();
			miDiapoCourant.Text = "&Dossier courant";
			miDiapoCourant.Shortcut = Shortcut.CtrlD;
			miDiapoCourant.Click += new EventHandler(DiapoCourant);
			
			RichMenuItem miRefresh = new RichMenuItem();
			miRefresh.Text = "&Rafraichir l'explorateur";
			miRefresh.Shortcut = Shortcut.F5;
			miRefresh.Click += new EventHandler(RefreshTree);
			
			RichMenuItem miAssos = new RichMenuItem();
			miAssos.Text = "Associer les fichiers images";
			miAssos.Click += new EventHandler(Associate);
			
			RichMenuItem miDAssos = new RichMenuItem();
			miDAssos.Text = "\"Desassocier\" les fichiers images";
			miDAssos.Click += new EventHandler(UnAssociate);
			
			RichMenuItem miEraseImage = new RichMenuItem();
			miEraseImage.Text = "Supprimer les images favorites";
			miEraseImage.Click += new EventHandler(EraseImage);
			RichMenuItem miEraseMusique = new RichMenuItem();
			miEraseMusique.Text = "Supprimer les musiques favorites";
			miEraseMusique.Click += new EventHandler(EraseMusique);
			RichMenuItem miEraseVideo = new RichMenuItem();
			miEraseVideo.Text = "Supprimer les videos favorites";
			miEraseVideo.Click += new EventHandler(EraseVideo);
			
			
			RichMenuItem miHTML = new RichMenuItem();
			miHTML.Text = "Exporter les images en album internet";
			miHTML.Click += new EventHandler(ExportAlbum);
			
			Menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miFichier,
																			miRecherche,
																			miDiapo,
																			miAlbum,
																			miOptions});
			miFichier.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miQuitter});
			miRecherche.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miRechercheImage,
																				miRechercheSon,
																				miRechercheVideo});
			miDiapo.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miDiapoCourant});
			miAlbum.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miHTML});
			miOptions.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miAssos,
																				miDAssos,
																				miRefresh,
																				miEraseImage,
																				miEraseMusique,
																				miEraseVideo});
		}
		
		private void EraseImage(object obj, EventArgs ea) {
			try
			{
				string str = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt");
				System.IO.File.Delete(str);
			}
			catch
			{
				
			}
			LoadFavorites();
		}
		
		private void EraseMusique(object obj, EventArgs ea) {
			try
			{
				string str = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt");
				System.IO.File.Delete(str);
			}
			catch
			{
				
			}
			LoadFavorites();
		}
		
		private void EraseVideo(object obj, EventArgs ea) {
			try
			{
				string str = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt");
				System.IO.File.Delete(str);
			}
			catch
			{
				
			}
			LoadFavorites();
		}
		
		private void ExportAlbum(object obj, EventArgs ea) {
			if(this.lvImages.Items.Count != 0)
			{
				Album alb = new Album(this.strDirectory);
				alb.ShowDialog();
			}
			else
				{
					MessageBox.Show("Il n'y a pas d'images dans ce repertoire !", "MediaView - Export");
				}
		}
		
		private void DiapoCourant(object obj, EventArgs ea) {
			string str = "";
			try
			{
				if(this.lvImages.Items.Count > 0)
				{
					str = this.dirTreeView.SelectedNode.FullPath.ToString();
					if((str.Substring(1, 2) == ":\\") && (str.Length < 4))
					{
						System.Diagnostics.Process.Start("Utils\\SlideShow.exe",str);
					}
					else
						{
							str = str.Insert(0, "\"");
							str = str.Insert(str.Length, "\"");
							System.Diagnostics.Process.Start("Utils\\SlideShow.exe",str);
						}
				}
				else
					{
						MessageBox.Show("Il n'y a pas d'images dans ce dossier");
					}
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}
		
		private void Recherche(object obj, EventArgs ea) {
			RichMenuItem rmi = (RichMenuItem)obj;
			string str = "";
			if(rmi.Text.EndsWith("images"))
			{
				str = "img";
			}
			else if(rmi.Text.EndsWith("sons"))
			{
				str = "mus";
			}
			else if(rmi.Text.EndsWith("videos"))
			{
				str = "vid";
			}
			else
				{
					str = "aut";
				}
			Farfouilleur far = new Farfouilleur(str);
			far.ShowDialog();
		}
		
		private void Quitter(object obj, EventArgs ea) {
			this.OnClosed(ea);
			Application.Exit();
		}
		
		private void RefreshTree(object obj, EventArgs ea) {
			this.dirTreeView.Dispose();
			this.dirTreeView = new System.Windows.Forms.DirectoryTreeView();
			this.dirTreeView.Parent = this.panel;
			this.dirTreeView.AfterSelect += new TreeViewEventHandler(StartFillListView);
			ReDraw();
		}
		
		private void InitializeFavFiles() {
			if(!Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer")))
			{
				Directory.CreateDirectory(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer"));
			}
			if(File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt")))
			{
				try
				{
					InternalLoadImage();
				}
				catch
				{
				}
			}
			else
				{
					File.Create(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt"));
				}
			if(File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt")))
			{
				try
				{
					InternalLoadImage();
				}
				catch
				{
				}
			}
			else
				{
					File.Create(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
				}
			if(File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt")))
			{
				try
				{
					InternalLoadImage();
				}
				catch
				{
				}
			}
			else
				{
					File.Create(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt"));
				}
		}
		
		private void LoadFavorites() {
			InitializeFavFiles();
			InternalLoadImage();
			InternalLoadMusique();
			InternalLoadVideo();
		
		private void InternalLoadImage() {
			this.lvFavImages.Items.Clear();
			StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt"));
			for(;;)
			{
				try
				{
					string str = sr.ReadLine();
					if(str.Length < 1)
					{
						sr.Close();
						this.lvFavImages.Sort();
						return;
					}
					this.lvFavImages.Items.Add(str);
				}
				catch
				{
					sr.Close();
					return;
				}
			}
		}
		
		private void InternalLoadMusique() {
			this.lvFavMusiques.Items.Clear();
			StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
			for(;;)
			{
				try
				{
					string str = sr.ReadLine();
					if(str.Length < 1)
					{
						sr.Close();
						this.lvFavMusiques.Sort();
						return;
					}
					this.lvFavMusiques.Items.Add(str);
				}
				catch
				{
					sr.Close();
					return;
				}
			}
		}
		
		private void InternalLoadVideo() {
			this.lvFavVideos.Items.Clear();
			StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt"));
			for(;;)
			{
				try
				{
					string str = sr.ReadLine();
					if(str.Length < 1)
					{
						sr.Close();
						this.lvFavVideos.Sort();
						return;
					}
					this.lvFavVideos.Items.Add(str);
				}
				catch
				{
					sr.Close();
					return;
				}
			}
		}
		
		///<summary>
		/// Methode qui associe les extensions au programme
		///<param name="obj">object representant le MenuItem appelant</param>
		/// <param name="ea">EventArgs du MenuItem</param> 
		///</summary>
		private void Associate(object obj, EventArgs ea) {
			RegistryKey regkey;
			RegistryKey regkeyOpen;
			//Creation des clefs principales
			regkey = Registry.ClassesRoot.CreateSubKey(".jpg");
			regkey.SetValue("", "MediaViewer.Image");
			regkey = Registry.ClassesRoot.CreateSubKey(".jpeg");
			regkey.SetValue("", "MediaViewer.Image");
			regkey = Registry.ClassesRoot.CreateSubKey(".gif");
			regkey.SetValue("", "MediaViewer.Image");
			regkey = Registry.ClassesRoot.CreateSubKey(".ico");
			regkey.SetValue("", "MediaViewer.Image");
			regkey = Registry.ClassesRoot.CreateSubKey(".bmp");
			regkey.SetValue("", "MediaViewer.Image");
			regkey = Registry.ClassesRoot.CreateSubKey(".png");
			regkey.SetValue("", "MediaViewer.Image");
			regkey.Close();
			
			//Creation de la commande ouvrir dans le menu
			regkeyOpen = Registry.ClassesRoot.CreateSubKey(@"MediaViewer.Image\shell\open\command");
			regkeyOpen.SetValue("", Environment.CurrentDirectory.ToString() + " %1");
			regkeyOpen.Close();
		}
		
		///<summary>
		/// Methode qui annule les associations d'extensions au programme
		///<param name="obj">object representant le MenuItem appelant</param>
		/// <param name="ea">EventArgs du MenuItem</param> 
		///</summary>
		private void UnAssociate(object obj, EventArgs ea) {
			RegistryKey regkey = Registry.ClassesRoot;
			regkey.DeleteSubKeyTree("MediaViewer.Jpg");	//On detruit simplement la clef
		}
	}
}
