// created on 27/05/2003 at 10:49
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace System.Windows.Forms
{
	public delegate void FileInfoPossibleEventHandler(object obj);   // delegate declaration
	public delegate void LoadFavEventHandler();
	
	public class RichListView : System.Windows.Forms.ListView
	{
		public event FileInfoPossibleEventHandler FileInfoPossible;
		public event LoadFavEventHandler LoadFav;
		
		public ListViewItem lviInfo;
		
		private string type;
		public string strDir;
		
		public bool farfouilleur;
		
		RichMenuItem miAddToFav = new RichMenuItem();
		
		public RichListView(string type) {
			this.type = type;
			this.Activation = ItemActivation.OneClick;
			this.Alignment = ListViewAlignment.SnapToGrid;
			this.HoverSelection = true;
			InitializeContextMenu();
		}
		
		protected override void OnSelectedIndexChanged(EventArgs ea) {
			base.OnSelectedIndexChanged(ea);
			
			int j = 0;
			try
			{
				foreach(ListViewItem i in this.SelectedItems)
				{
					j++;
				}
				if(j <= 1)
				{
					this.lviInfo = this.SelectedItems[0];
					FileInfoPossible(this.lviInfo);
				}
				else
					{
						this.lviInfo = null;
					}
			}
			catch
			{
			}
		}
		
		protected override void OnItemActivate(EventArgs ea) {
			base.OnItemActivate(ea);
			
			switch(this.type)
			{
				case "img":	foreach(ListViewItem lvi in this.SelectedItems)
							{
								if(farfouilleur)
								{
									try
									{
										Process.Start("Utils\\PictureDisplayer.exe", "\"" + lvi.Text + "\"");
									}
									catch
									{
										MessageBox.Show("Impossible d'ouvrir " + lvi.Text + " avec un Plug-In,\n le module doit etre endommage.\nLe fichier va etre ouvert avec le programme par defaut de votre ordinateur.", "MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
										try
										{
											Process.Start(lvi.Text);
										}
										catch(System.ComponentModel.Win32Exception)
										{
											MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
										}
										continue;
									}
								}
								else
									{
										try
										{
											Process.Start("Utils\\PictureDisplayer.exe", "\"" + Path.Combine(strDir, lvi.Text) + "\"");
										}
										catch
										{
											MessageBox.Show("Impossible d'ouvrir " + lvi.Text + "avec un Plug-In,\n le module doit etre endommage.\nLe fichier va etre ouvert avec le programme par defaut de votre ordinateur.", "MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
											try
											{
												Process.Start(Path.Combine(strDir, lvi.Text));
											}
											catch(System.ComponentModel.Win32Exception)
											{
												MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
											}
											continue;
										}
									}
							}
							break;
				case "pls":	foreach(ListViewItem lvi in this.SelectedItems)
							{
								if(farfouilleur)
								{
									try
									{
										Process.Start(lvi.Text);
									}
									catch(System.ComponentModel.Win32Exception)
									{
										MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
									}
									continue;
								}
								else
									{
										try
										{
											Process.Start(Path.Combine(strDir, lvi.Text));
										}
										catch(System.ComponentModel.Win32Exception)
										{
											MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
										}
										continue;
									}
							}
							break;
				case "mus":	foreach(ListViewItem lvi in this.SelectedItems)
							{
								if(farfouilleur)
								{
									try
									{
										Process.Start(lvi.Text);
									}
									catch(System.ComponentModel.Win32Exception)
									{
										MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
									}
									continue;
								}
								else
									{
										try
										{
											Process.Start(Path.Combine(strDir, lvi.Text));
										}
										catch(System.ComponentModel.Win32Exception)
										{
											MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
										}
										continue;
									}
							}
							break;
				case "vid":	foreach(ListViewItem lvi in this.SelectedItems)
							{
								if(farfouilleur)
								{
									try
									{
										Process.Start(lvi.Text);
									}
									catch(System.ComponentModel.Win32Exception)
									{
										MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
									}
									continue;
								}
								else
									{
										try
										{
											Process.Start(Path.Combine(strDir, lvi.Text));
										}
										catch(System.ComponentModel.Win32Exception)
										{
											MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
										}
										continue;
									}
							}
							break;
				case "aut":	foreach(ListViewItem lvi in this.SelectedItems)
							{
								if(farfouilleur)
								{
									try
									{
										Process.Start(lvi.Text);
									}
									catch(System.ComponentModel.Win32Exception)
									{
										MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
									}
									continue;
								}
								else
									{
										try
										{
											Process.Start(Path.Combine(strDir, lvi.Text));
										}
										catch(System.ComponentModel.Win32Exception)
										{
											MessageBox.Show("Aucune application n'est capable d'ouvrir ce fichier.","MediaViewer", MessageBoxButtons.OK, MessageBoxIcon.Information);
										}
										continue;
									}
							}
							break;
				default : break;
			}
		}
		
		private void InitializeContextMenu() {
			this.ContextMenu = new ContextMenu();
			this.ContextMenu.MenuItems.Clear();
			
			switch(this.type)
			{
				case "img":	miAddToFav.Text = "Ajouter aux images favorites";
							miAddToFav.Click += new EventHandler(AddToFav);
							this.ContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miAddToFav});
							break;
				case "pls":	miAddToFav.Text = "Ajouter aux musiques favorites";
							this.ContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miAddToFav});
							break;
				case "mus":	miAddToFav.Text = "Ajouter aux musiques favorites";
							this.ContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miAddToFav});
							break;
				case "vid":	miAddToFav.Text = "Ajouter aux videos favorites";
							this.ContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miAddToFav});
							break;
			}
		}
		
		void AddToFav(object obj, EventArgs ea) {
			switch(this.type)
			{
				case "img" : 	foreach(ListViewItem lvi in this.SelectedItems)
								{
									try
									{
										StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt"));
										string str = sr.ReadToEnd();
										sr.Close();
										StreamWriter sw = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favimg.txt"));
										sw.Write(str);
										sw.WriteLine(Path.Combine(this.strDir, lvi.Text));
										sw.Close();
									}
									catch
									{
									}
								}
								LoadFav();
								break;
				case "pls" : 	foreach(ListViewItem lvi in this.SelectedItems)
								{
									try
									{
										StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
										string str = sr.ReadToEnd();
										sr.Close();
										StreamWriter sw = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
										sw.Write(str);
										sw.WriteLine(Path.Combine(this.strDir, lvi.Text));
										sw.Close();
									}
									catch
									{
									}
								}
								LoadFav();
								break;
				case "mus" : 	foreach(ListViewItem lvi in this.SelectedItems)
								{
									try
									{
										StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
										string str = sr.ReadToEnd();
										sr.Close();
										StreamWriter sw = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favmus.txt"));
										sw.Write(str);
										sw.WriteLine(Path.Combine(this.strDir, lvi.Text));
										sw.Close();
									}
									catch
									{
									}
								}
								LoadFav();
								break;
				case "vid" : 	foreach(ListViewItem lvi in this.SelectedItems)
								{
									try
									{
										StreamReader sr = new StreamReader(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt"));
										string str = sr.ReadToEnd();
										sr.Close();
										StreamWriter sw = new StreamWriter(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MediaViewer\\favvid.txt"));
										sw.Write(str);
										sw.WriteLine(Path.Combine(this.strDir, lvi.Text));
										sw.Close();
									}
									catch
									{
									}
								}
								LoadFav();
								break;
			}
		}
	}
}
