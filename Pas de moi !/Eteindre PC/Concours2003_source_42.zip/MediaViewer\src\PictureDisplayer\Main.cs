using System;
using System.Windows.Forms;

namespace PictureDisplayer
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			
			try
			{
				PictureDisplayer picDisp = new PictureDisplayer(args[0]);
				Environment.CurrentDirectory = System.IO.Path.Combine(Environment.CurrentDirectory, "Utils");
				Application.Run(picDisp);
			}
			catch
			{
				Console.Out.WriteLine("Utilisation : PictureDisplayer <NomFichier>");
			}
		}
	}
}
