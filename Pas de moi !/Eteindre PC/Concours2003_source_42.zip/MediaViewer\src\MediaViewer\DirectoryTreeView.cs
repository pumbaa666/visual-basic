using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;

using System.Runtime.InteropServices;

namespace System.Windows.Forms
{
	class DirectoryTreeView : TreeView
	{
		ResourceManager rm = new ResourceManager("ViewerBmp", Assembly.GetCallingAssembly());
			
		public const uint SHGFI_ICON				= 0x000000100;     // get icon
		public const uint SHGFI_SELECTED			= 0x000010000;     // show icon in selected state
		public const uint SHGFI_SMALLICON			= 0x000000001;     // get small icon
		
		[DllImport("Shell32.dll")]
		public static extern int SHGetFileInfo( string pszPath, uint
			dwFileAttributes, ref SHFILEINFO psfi, uint cbfileInfo, uint uFlags);

		[ StructLayout( LayoutKind.Sequential ) ]
			public struct SHFILEINFO
		{
			public IntPtr hIcon;
			public int iIcon;
			public uint dwAttributes;
			[MarshalAs(UnmanagedType.LPStr, SizeConst=260)] public string szDisplayName;
			[MarshalAs(UnmanagedType.LPStr, SizeConst=80)] public string szTypeName;
		};
		
		
		public DirectoryTreeView()
		{
			this.PathSeparator = @"\";
			this.Width *= 2;
			RefreshTree();
		}
		
		void RefreshTree()
		{
			this.BeginUpdate();
			this.Nodes.Clear();
			
			string[] lecteurs = Directory.GetLogicalDrives();
			
			this.ImageList = new ImageList();
			this.ImageList.Images.Add((Bitmap)rm.GetObject("closeFolder"));
			this.ImageList.Images.Add((Bitmap)rm.GetObject("openFolder"));
			
			foreach(string str in lecteurs)
			{
				Icon ico = getSmallIcon(str);
				Icon ico2 = getSmallIconSelected(str);
				this.ImageList.Images.Add(ico);
				this.ImageList.Images.Add(ico2);
				
				TreeNode tn = new TreeNode(str , this.ImageList.Images.Count - 2, this.ImageList.Images.Count - 1);
				this.Nodes.Add(tn);
				AddDirectories(tn);
				this.EndUpdate();
			}
		}
		
		private void AddDirectories(TreeNode tn)
		{
			tn.Nodes.Clear();
			string path = tn.FullPath;
			DirectoryInfo dirInfo = new DirectoryInfo(path);
			DirectoryInfo[] aDirInfo;
			
			try
			{
				aDirInfo = dirInfo.GetDirectories();
			}
			catch
			{
				return;
			}
			
			foreach(DirectoryInfo di in aDirInfo)
			{
				if(di.Name.ToUpper() == "SYSTEM VOLUME INFORMATION" || di.Name.ToUpper() == "SYSTEM" || di.Name.ToUpper() == "SYSTEM32" || di.Name.ToUpper() == "WINDOWS" || di.Name.ToUpper() == "WINNT")
				{
					continue;
				}
				TreeNode tnDir = new TreeNode(di.Name, 0, 1);
				tn.Nodes.Add(tnDir);
			}
		}
		
		private Icon getSmallIcon( string path )
		{
			SHFILEINFO info = new SHFILEINFO();
			SHGetFileInfo( path, 0, ref info, (uint) Marshal.SizeOf(info), SHGFI_ICON | SHGFI_SMALLICON );
			
			Icon ico = Icon.FromHandle( info.hIcon );
			return ico;
		}

		private Icon getSmallIconSelected( string path )
		{
			SHFILEINFO info = new SHFILEINFO();
			SHGetFileInfo( path, 0, ref info, (uint) Marshal.SizeOf(info), SHGFI_ICON | SHGFI_SMALLICON | SHGFI_SELECTED );
			
			Icon ico = Icon.FromHandle( info.hIcon );
			return ico;
		}
		
		protected override void OnBeforeExpand(TreeViewCancelEventArgs tvcea)
		{
			base.OnBeforeExpand(tvcea);
			this.BeginUpdate();
			foreach(TreeNode tn in tvcea.Node.Nodes)
			{
				this.AddDirectories(tn);
			}
			this.EndUpdate();
		}
	}
}
