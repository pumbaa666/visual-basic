using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Win32;



namespace System.Windows.Forms
{
	/// <remarks>Cette version ne permet pas encore de crer des menus parent mais offre la possibilit de crer des items de menus Parent</remarks>
    public class RichMenuItem :  System.Windows.Forms.MenuItem
    {
        public Font font;          //la Font du menu
        public Bitmap bitmap;      //l'image du menu
        public Color backColor;    //'couleur de fond du menu
        public Color textColor;    //'couleur du texte
        public Color selectedColor;//'couleur quand la souris passe dessus
        public Color selectedBorderColor;//'couleur de la bordure quand on se dplace sur un menuitem
        public Color selectedTextColor;//'couleur du texte quand il est slectionn
        public Color margeColor;  // 'couleur de la marge de gauche
        public Color _transparentColor;//'couleur de transparence
        public int marge;   //'largeur de la marge de gauche
        public String sHelpText;   //'texte d'aide


		//marge entre le texte et ses cts
        private const int espacement = 4;



		/// <summary>
		/// Font utilise pour le texte des menus 
		/// </summary>
		/// <example>FontMenu = new Font("trebucbd.ttf", 20, FontStyle.Bold | FontStyle.Underline)</example>
		Font FontMenu
		{
			get
			{
				return font;
			}
			set
			{
				font = value;
			}
		}
	

		/// <summary>
		/// Couleur de transparence de l'image associe au menu
		/// </summary>
		/// <remarks>La couleur de transparence par dfaut est choisie  partir du prixel en position (0,0) par dfaut</remarks>
		/// <example>TransparentColor = IconeMenu.GetPixel(1, 1);//met la couleur de transparence pour le pixel en position 1.1</example>
		Color TransparentColor
		{
			get
			{
				return _transparentColor;
			}
			set
			{
				_transparentColor = value;
				bitmap.MakeTransparent(_transparentColor);
			}
		}
		
		/**
		 * méthode qui calcule la taille d'un menu avant l'affichage de celui-ci
		 */
        protected override  void OnMeasureItem(System.Windows.Forms.MeasureItemEventArgs e )
        {
           
            //classe est faite pour les Items de menus et pas pour les menus eux mmes
            if (this.Parent is MainMenu)
            {
                throw new Exception("ce type de menu item n'accepte pas encore d'tre un menuitem parent");
            }

            //spcifier la hauteur si il s'agit d'un sprateurr
			if (this.Text == "-" )
			{
				e.ItemHeight = 1;
			}
			else
			{
				//Pour calculer l'espace utilis par le texte
				StringFormat mStringFormat = new StringFormat();

				//spcifier la lettre souligne
				mStringFormat.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Show;

				//calculer la taille de l'item
				e.ItemWidth = (int)(e.Graphics.MeasureString(this.Text, this.font, 1000, mStringFormat).Width) + 2 * espacement;
 
				//calculer l'espace utilis par le bitmap
				e.ItemWidth += marge;

				//calculer l'espace utilis par le raccourci clavier
				if (this.Shortcut != Shortcut.None && this.ShowShortcut)
				{
					e.ItemWidth += espacement + (int)(e.Graphics.MeasureString(" " + this.ShortCutText(), this.font).Width);
				}
				e.ItemHeight = marge;
			}
        }
        
        
        
        
        
        
		/**
		 * fonction qui dessine le menu
		 */
		protected override void  OnDrawItem(System.Windows.Forms.DrawItemEventArgs e)
        {
            //verifier qu'il n'a s'agit pas d'un menu (il faut tre item de menu
			if (this.Parent is MainMenu)
			{
                throw new Exception("ce type de menu item n'accepte pas encore d'tre un menuitem parent");
            }

            //initialiser les rectangles contenants le bitmap et le texte
            RectangleF mRectBitmap = new RectangleF(e.Bounds.Left, e.Bounds.Top, marge, marge);
            RectangleF mRectTexte = new RectangleF(e.Bounds.Left + marge, e.Bounds.Top, e.Bounds.Width - marge, marge);
            Rectangle mClientRect = new Rectangle(e.Bounds.Left, e.Bounds.Top, e.Bounds.Width - 1, e.Bounds.Height - 1);

            //dessiner un sprateur s'il s'agit d'un sprateur
			if (this.Text == "-" )
			{
				Pen stylo = new Pen(this.textColor, 1);
	
				e.Graphics.FillRectangle(new SolidBrush(this.backColor), mRectTexte);
				e.Graphics.FillRectangle(new SolidBrush(this.margeColor), mRectBitmap);
				e.Graphics.DrawLine(stylo, e.Bounds.Left + marge + espacement*2, e.Bounds.Top + (int)(e.Bounds.Height / 2), e.Bounds.Left + e.Bounds.Width, e.Bounds.Top + (int)(e.Bounds.Height / 2));
			}
			//sinon...
			else
			{
				//si la souris est sur l'item
				if (IsSelected(e.State) && !IsDisabled(e.State))
				{ 
					//spcifier la couleur de fond
					e.Graphics.FillRectangle(getCurrentBackColor(e.State), mClientRect);
					//et le cadre autour...
					e.Graphics.DrawRectangle(new Pen(this.selectedBorderColor), mClientRect);
				}
				//sinon...
				else
				{
					//spcifier la couleur du cadre de gauche
					e.Graphics.FillRectangle(new SolidBrush(this.margeColor), mRectBitmap);
					//et la couleur de fond
					e.Graphics.FillRectangle(getCurrentBackColor(e.State), mRectTexte);
				}
            

				//y'a t'il une coche ?
				if ( (e.State & (DrawItemState.Checked)) != 0)
				{
					//spcifier la couleur de la petite box
					e.Graphics.FillRectangle(new SolidBrush(this.selectedColor), e.Bounds.Left + 2, e.Bounds.Top + 2, marge - 5, marge - 5);
					//spcifier la couleur du cadre de la petite box
					e.Graphics.DrawRectangle(new Pen(this.selectedBorderColor), e.Bounds.Left + 2, e.Bounds.Top + 2, marge - 5, marge - 5);
					//dessiner la coche
					e.Graphics.DrawImage(this.CheckBitmap(), e.Bounds.Left+ espacement/2, e.Bounds.Top);
				}


				//crire le texte du menu

				//crer un objet pour manipuler le texte
				StringFormat mStringFormat = new StringFormat();

				//ecrire au plus prs
				mStringFormat.Alignment = StringAlignment.Near;
				//dssiner au milieu (en hauteur)
				mStringFormat.LineAlignment = StringAlignment.Center;
				//spcifier la lettre qui doit tre souligne
				mStringFormat.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.Show;
				//crer le reactangle contenant le primtre  crire
				RectangleF mRF = RectangleF.Empty;
 
				//spcifier les bornes de ce primtre
				mRF.X = mRectTexte.X + espacement;
				mRF.Y = mRectTexte.Y;
				mRF.Width = mRectTexte.Width - espacement;
				mRF.Height = mRectTexte.Height;

				//crire le texte
				e.Graphics.DrawString(this.Text, this.font, getCurrentTextColor(e.State), mRF, mStringFormat);
            
				//y'a t'il un raccourcis clavier ?
				if (this.Shortcut != Shortcut.None && this.ShowShortcut)
				{ 
					//dessiner maintenant a droite
					mStringFormat.Alignment = StringAlignment.Far;
					//crire le raccourcis
					e.Graphics.DrawString(this.ShortCutText(), this.font, getCurrentTextColor(e.State), mRF, mStringFormat);
				}


				//y'a t'il un bitmap ?
				if ( this.bitmap != null)
				{ 
					try
					{
						//spcifier la couleur de transparence
						this.bitmap.MakeTransparent(this._transparentColor);
					}
					catch
					{

					}

					//si le menu peut tre slectionn...
					if (!IsDisabled(e.State) )
					{
						//...et si justement la souris est dessus
						if (IsSelected(e.State) )
						{
							e.Graphics.Flush();
							//dcaler le dessin avec ombrage
							ControlPaint.DrawImageDisabled(e.Graphics, this.bitmap, e.Bounds.Left + espacement, e.Bounds.Top + espacement, this.margeColor);
							e.Graphics.DrawImage(this.bitmap, e.Bounds.Left + espacement - 1, e.Bounds.Top + espacement - 1, bitmap.Width, bitmap.Height);
						}
						//sinon...
						else
						{
							//dessiner le dessin tout bte
							e.Graphics.DrawImage(this.bitmap, e.Bounds.Left + espacement, e.Bounds.Top + espacement, bitmap.Width, bitmap.Height);
						}
					}
					//sinon...
					else
					{
						ControlPaint.DrawImageDisabled(e.Graphics, this.bitmap, e.Bounds.Left + espacement, e.Bounds.Top + espacement, this.margeColor);
					}
				}
			}
			e.Graphics.Flush();
		}




 
        
		/**
		* Mthode qui renvoie la couleur du texte en fonction du contexte
		*/
		protected Brush getCurrentTextColor(DrawItemState State)
        {
            //'s'il est inactif
            if (IsDisabled(State) )
                return new SolidBrush(SystemColors.GrayText);
            
            if (IsSelected(State) )
                return new SolidBrush(this.selectedTextColor);
            else
                return new SolidBrush(this.textColor);
        }
        
        
        
	    /**
		 * Mthode qui renvoie la couleur du fond en fonction du contexte
		 */
		protected SolidBrush getCurrentBackColor(DrawItemState State  )
        {
            if (IsDisabled(State) )
                return new SolidBrush(backColor);
            
            if (IsSelected(State) )
                return new SolidBrush(selectedColor);
            else
                return new SolidBrush(backColor);
            
        }
        
        
		/**
		 * Mthode qui indique si le menu est actuellement slectionn
		 */
		protected bool IsSelected(DrawItemState State)
        { 
            return ( (State & DrawItemState.Selected) != 0);
        }
        
        
		/**
		 * Mthode qui indique si le menu est cliquable
		 */
		protected bool IsDisabled(DrawItemState State)
        {
			return ( (State & DrawItemState.Disabled) != 0);
        }
        
        
        
		/**
		 * Mthode qui renvoie sous la forme d'une string le raccourcis clavier
		 */
		protected  String ShortCutText()
        {
            //'si il n'y en a pas ou qu'on ne le montre pas, on retourne le vide
                if (this.Shortcut == Shortcut.None || this.ShowShortcut == false )
                    return "";

                //'y'en a un
                Keys k = (Keys)(Shortcut);
                return System.ComponentModel.TypeDescriptor.GetConverter(k.GetType()).ConvertToString(k);

        }
        
        
		/**
		 * Mthode qui dssine une coche et renvoie le bitmap correspondant
		 * avec la transparence associe
		 */
		protected Bitmap CheckBitmap() 
		{
            
			Bitmap mB = new Bitmap(marge, marge);
			Graphics g   = Graphics.FromImage(mB);
			Size mS  = SystemInformation.MenuCheckSize;

			ControlPaint.DrawMenuGlyph(g, new Rectangle((int)((marge - mS.Width) / 2), (int)((marge - mS.Height) / 2), mS.Width, mS.Height), MenuGlyph.Checkmark);
			mB.MakeTransparent(mB.GetPixel((int)((marge - mS.Width) / 2), (int)((marge - mS.Height) / 2)));
			g.Dispose();
			return mB;
		}




		//////////////////////////////////////////////////////////////////




		/// <summary>
		/// mthode qui initialise tous les membres d'un menu avec des valeurs par dfaut 
		/// </summary>
		/// <remarks>Les menus par dfaut sont assez similaires aux menus Win 98</remarks>
		public void InitialiserValeursParDfaut()
		{
			this.font = SystemInformation.MenuFont;
			this.backColor = SystemColors.Menu;
			this.textColor = SystemColors.WindowText;
			this.selectedColor = SystemColors.ControlLight;
			this.selectedBorderColor = SystemColors.InactiveCaption;
			this.selectedTextColor = SystemColors.WindowText;
			this.margeColor = SystemColors.ControlLight;
			this.marge = 24;
			this.OwnerDraw = true;
		}




		//////////////////////////////////////////////////////////////////




		
		/// <summary>
		/// Constructeur par dfaut de la classe MenuItem
		/// </summary>
		/// <remarks>Le constructeur par dfaut initialise et cr un menu avec des valeurs par dfaut</remarks>
		public RichMenuItem ()
        {
            InitialiserValeursParDfaut();
        }


		/// <summary>
		/// Constructeur par dfaut de la classe MenuItem
		/// </summary>
		/// <param name="text">Text situ dans le menu</param>
		public RichMenuItem(String text)
        {
            this.InitialiserValeursParDfaut();
			this.Text = text;
		}
            

		/// <summary>
		/// Constructeur permettent de spcifier le texte du menu
		/// </summary>
		/// <param name="menuText">Text situ dans le menu</param>
		/// <param name="icone">image associe au menu lors de son affichage</param>
		public RichMenuItem(String menuText, Bitmap icone)
        {
			InitialiserValeursParDfaut();
			this.bitmap = icone;
			this.Text = menuText;
			if (this.bitmap != null)
            { 
                this._transparentColor = this.bitmap.GetPixel(0, 0);
            }
         }
        

		/// <summary>
		/// Constructeur acceptant en paramtre le texte du menu
		/// ainsi que la mthode appele lors du clik et l'image icone associe
		/// </summary>
		/// <param name="menuText">Text situ dans le menu</param>
		/// <param name="icone">image associe au menu lors de son affichage</param>
		/// <param name="HandlerClick">Mthode appele lorsque le menu est click</param>
		public RichMenuItem(String menuText, EventHandler HandlerClick , Bitmap icone )
		{
			InitialiserValeursParDfaut();
			this.Text = menuText;
			this.Click += HandlerClick;
			this.bitmap = icone;
			if (this.bitmap != null)
			{ 
				this._transparentColor = this.bitmap.GetPixel(0, 0);
			}
            
		}


		/// <summary>
		/// Constructeur acceptant en paramtre le texte du menu
		/// ainsi que la mthode appele lors du clik, l'image icone associe 
		/// le raccourcis associ, les couleurs associes
		/// </summary>
		/// <param name="menuText">Text situ dans le menu</param>
		/// <param name="icone">image associe au menu lors de son affichage</param>
		/// <param name="HandlerClick">Mthode appele lorsque le menu est click</param>
		/// <param name="shortcut">raccourcis clavier du menu (voir numration Shortcut)</param>
		/// <param name="couleurFond">Couleur de fond du menu</param>
		/// <param name="couleurMarge">Couleur de la marge de gauche du menu</param>
		/// <param name="couleurSelection">Couleur de la selection du menu lorsque la souris passe au dessus</param>
		public RichMenuItem(String menuText, EventHandler HandlerClick , Bitmap icone, Shortcut shortcut, Color couleurFond, Color couleurMarge, Color couleurSelection )
		{
			InitialiserValeursParDfaut();
			this.Text = menuText;
			this.Click += HandlerClick;
			this.bitmap = icone;
			if (this.bitmap != null)
			{ 
				this._transparentColor = this.bitmap.GetPixel(0, 0);
			}

			if (shortcut != Shortcut.None)
			{ 
				this.Shortcut = shortcut;
			}

			this.margeColor = couleurMarge;
			this.backColor = couleurFond;
			this.selectedColor = couleurSelection;
		}

    }
}
