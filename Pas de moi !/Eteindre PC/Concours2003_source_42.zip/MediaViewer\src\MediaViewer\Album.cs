// created on 02/06/2003 at 12:12
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MediaViewer {
	public class Album : System.Windows.Forms.Form
	{
		private System.IO.StreamWriter sw;
		private int i;
		private int max;
		
		private Image image;
		private PictureBox picBox;
		private TextBox commentaire;
		private Label lblComment;
		private CheckBox chkBox;
		
		private string strDir;
		
		private Label lblNouvelleTaille;
		private Label lblM;
		
		private Label lblCouleurs;
		private Label lblBackGround;
		private Label lblLink;
		private Label lblALink;
		private Label lblVLink;
		private Label lblText;
		private Label lblTitre;
		
		private TextBox tbBackGround;
		private TextBox tbLink;
		private TextBox tbALink;
		private TextBox tbVLink;
		private TextBox tbText;
		private TextBox tbTitre;
		
		private NumericUpDown width;
		private NumericUpDown height;
		
		private Button btn;
		
		private string[] fichiers;
		
		public Album(string strDir)
		{
			try
			{
				this.fichiers = System.IO.Directory.GetFiles(strDir);
			}
			catch(Exception e)
			{
				MessageBox.Show(e.ToString());
				this.Close();
			}
			this.max = this.fichiers.Length;
			
			this.strDir = strDir;
			InitializeComponent();
			this.ClientSize = new System.Drawing.Size(this.height.Right + 10, this.btn.Bottom + 10);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.ShowInTaskbar = false;
		}
		
		void InitializeComponent() {
			this.lblNouvelleTaille = new Label();
			this.lblNouvelleTaille.Text = "Nouvelle taille des images (Long. * larg.) :";
			this.lblNouvelleTaille.Parent = this;
			this.lblNouvelleTaille.AutoSize = true;
			this.lblNouvelleTaille.Location = new System.Drawing.Point(10, 10);
			
			this.width = new NumericUpDown();
			this.width.Parent = this;
			this.width.Minimum = 0;
			this.width.Maximum = 2147483647;
			this.width.Location = new System.Drawing.Point(this.lblNouvelleTaille.Right + 5, 8);
			this.width.Width = 70;
			
			this.lblM = new Label();
			this.lblM.Text = "*";
			this.lblM.Parent = this;
			this.lblM.AutoSize = true;
			this.lblM.Location = new System.Drawing.Point(this.width.Right + 3, 10);
			
			this.height = new NumericUpDown();
			this.height.Parent = this;
			this.height.Minimum = 0;
			this.height.Maximum = 2147483647;
			this.height.Location = new System.Drawing.Point(this.lblM.Right + 3, 8);
			this.height.Width = 70;
			
			this.lblCouleurs = new Label();
			this.lblCouleurs.Parent = this;
			this.lblCouleurs.Text = "Personnalisez les couleurs, Couleurs nommees ou en Hexa (avec le #) :";
			this.lblCouleurs.AutoSize = true;
			this.lblCouleurs.Location = new System.Drawing.Point(10, this.height.Bottom + 20);
			
			this.lblBackGround = new Label();
			this.lblBackGround.Parent = this;
			this.lblBackGround.Text = "Couleur de fond :";
			this.lblBackGround.AutoSize = true;
			this.lblBackGround.Location = new System.Drawing.Point(10, this.lblCouleurs.Bottom + 10);
			
			this.tbBackGround = new TextBox();
			this.tbBackGround.Parent = this;
			this.tbBackGround.Text = "#3864bd";
			this.tbBackGround.Location = new System.Drawing.Point(this.lblBackGround.Right + 5, this.lblCouleurs.Bottom + 10);
			
			this.lblLink = new Label();
			this.lblLink.Parent = this;
			this.lblLink.Text = "Couleur des liens :";
			this.lblLink.AutoSize = true;
			this.lblLink.Location = new System.Drawing.Point(10, this.lblBackGround.Bottom + 10);
			
			this.tbLink = new TextBox();
			this.tbLink.Parent = this;
			this.tbLink.Text = "Blue";
			this.tbLink.Location = new System.Drawing.Point(this.lblLink.Right + 5, this.lblBackGround.Bottom + 10);
			
			this.lblALink = new Label();
			this.lblALink.Parent = this;
			this.lblALink.Text = "Couleur des liens actifs :";
			this.lblALink.AutoSize = true;
			this.lblALink.Location = new System.Drawing.Point(10, this.lblLink.Bottom + 10);
			
			this.tbALink = new TextBox();
			this.tbALink.Parent = this;
			this.tbALink.Text = "Red";
			this.tbALink.Location = new System.Drawing.Point(this.lblALink.Right + 5, this.lblLink.Bottom + 10);
			
			this.lblVLink = new Label();
			this.lblVLink.Parent = this;
			this.lblVLink.Text = "Couleur des liens visites :";
			this.lblVLink.AutoSize = true;
			this.lblVLink.Location = new System.Drawing.Point(10, this.lblALink.Bottom + 10);
			
			this.tbVLink = new TextBox();
			this.tbVLink.Parent = this;
			this.tbVLink.Text = "Blue";
			this.tbVLink.Location = new System.Drawing.Point(this.lblVLink.Right + 5, this.lblALink.Bottom + 10);
			
			this.lblText = new Label();
			this.lblText.Parent = this;
			this.lblText.Text = "Couleur du texte :";
			this.lblText.AutoSize = true;
			this.lblText.Location = new System.Drawing.Point(10, this.lblVLink.Bottom + 10);
			
			this.tbText = new TextBox();
			this.tbText.Parent = this;
			this.tbText.Text = "White";
			this.tbText.Location = new System.Drawing.Point(this.lblText.Right + 5, this.lblVLink.Bottom + 10);
			
			this.lblTitre = new Label();
			this.lblTitre.Parent = this;
			this.lblTitre.Text = "Titre de la page :";
			this.lblTitre.AutoSize = true;
			this.lblTitre.Location = new System.Drawing.Point(10, this.lblText.Bottom + 10);
			
			this.tbTitre = new TextBox();
			this.tbTitre.Parent = this;
			this.tbTitre.Text = "Album photo";
			this.tbTitre.Location = new System.Drawing.Point(this.lblTitre.Right + 5, this.lblText.Bottom + 10);
			
			this.btn = new Button();
			this.btn.Parent = this;
			this.btn.Text = "Ok";
			this.btn.FlatStyle = FlatStyle.System;
			this.btn.Location = new System.Drawing.Point(this.height.Right - this.btn.Width, this.tbTitre.Bottom);
			this.btn.Click += new EventHandler(FirstValid);
		}
		
		private void FirstValid(object obj, EventArgs ea) {
			try
			{
				System.IO.Directory.CreateDirectory(System.IO.Path.Combine(this.strDir, "thumbs"));
				sw = System.IO.File.CreateText(System.IO.Path.Combine(this.strDir, "index.html"));
				FillHTML();
			}
			catch(Exception e)
			{
				MessageBox.Show(e.ToString());
				sw.Close();
				this.Close();
			}
		}
		
		private void FillHTML() {
			this.lblALink.Visible = false;
			this.lblBackGround.Visible = false;
			this.lblCouleurs.Visible = false;
			this.lblLink.Visible = false;
			this.lblM.Visible = false;
			this.lblNouvelleTaille.Visible = false;
			this.lblText.Visible = false;
			this.lblTitre.Visible = false;
			this.lblVLink.Visible = false;
			this.tbALink.Visible = false;
			this.tbBackGround.Visible = false;
			this.tbLink.Visible = false;
			this.tbText.Visible = false;
			this.tbTitre.Visible = false;
			this.tbVLink.Visible = false;
			this.height.Visible = false;
			this.width.Visible = false;
			this.btn.Visible = false;
			
			this.picBox = new PictureBox();
			this.picBox.Parent = this;
			this.picBox.Visible = true;
			this.picBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.picBox.Size = new System.Drawing.Size((int)this.width.Value, (int)this.height.Value);
			this.picBox.Location = new System.Drawing.Point(0, 0);
			
			this.lblComment = new Label();
			this.lblComment.Parent = this;
			this.lblComment.Text = "Commentaire :";
			this.lblComment.AutoSize = true;
			this.lblComment.Location = new System.Drawing.Point(0, this.picBox.Bottom + 10);
			
			this.commentaire = new TextBox();
			this.commentaire.Parent = this;
			this.commentaire.Multiline = true;
			this.commentaire.ScrollBars = ScrollBars.Vertical;
			this.commentaire.Size = new System.Drawing.Size(400, 200);
			this.commentaire.Location = new System.Drawing.Point(0, this.lblComment.Bottom);
			
			this.chkBox = new CheckBox();
			this.chkBox.Parent = this;
			this.chkBox.Text = "Ne pas incorporer cette image.";
			this.chkBox.FlatStyle = FlatStyle.System;
			this.chkBox.Checked = false;
			this.chkBox.Location = new System.Drawing.Point(0, this.commentaire.Bottom + 10);
			
			this.btn = new Button();
			this.btn.Parent = this;
			this.btn.Text = "Suivante";
			this.btn.FlatStyle = FlatStyle.System;
			this.btn.Click += new EventHandler(AddPicture);
			
			this.ClientSize = new System.Drawing.Size(Math.Max(this.picBox.Width, 400), 10);
			
			this.btn.Location = new System.Drawing.Point(this.ClientSize.Width - this.btn.Width - 10, this.commentaire.Bottom + 5);
			
			this.ClientSize = new System.Drawing.Size(this.ClientSize.Width, this.btn.Right + 5);
			
			foreach(string str in fichiers)
			{
				if(IsPicture(str))
				{
					break;
				}
				else
					{
						i++;
					}
			}
			
			RefreshPage();
			
			try
			{
				sw.Write(	"<html>\n" +
							"<head>\n" +
							"<title>" + this.tbTitre.Text + "</title>\n" +
							"</head>\n" +
							"<body bgcolor=\"" + this.tbBackGround.Text + "\"" +
								   "text=\"" + this.tbText.Text + "\"" +
								   "link=\"" + this.tbLink.Text + "\"" +
								   "alink=\"" + this.tbALink.Text + "\"" +
								   "vlink=\"" + this.tbVLink.Text + "\"" +
							">\n" +
							"<table border=\"0\" width=\"100%\">");
			}
			catch(Exception e)
			{
				MessageBox.Show(e.ToString());
				this.Close();
			}
		}
		
		private bool IsPicture(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".JPG") || path.EndsWith(".JPEG") || path.EndsWith(".BMP") || path.EndsWith(".GIF") || path.EndsWith(".PNG") || path.EndsWith(".ICO"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
		
		private void AddPicture(object obj, EventArgs ea) {
			if(i < this.max)
			{
				for(;;)
				{
					if(IsPicture(fichiers[i]))
					{
						break;
					}
					else
						{
							i++;
							if(i >= this.max)
							{
								this.Close();
							}
						}
				}
				if(this.chkBox.Checked)
				{
					i++;
					RefreshPage();
					return;
				}
				else
					{
						if(IsPicture(fichiers[i]))
						{
							if(fichiers[i].Substring(2, 2) == "\\\\")
							{
								fichiers[i] = fichiers[i].Remove(2, 1);
							}
							string path = this.strDir + "\\thumbs\\" + System.IO.Path.GetFileName(fichiers[i]);
							try
							{
							sw.Write(	"<tr>\n" +
										"<td width=\"" + (int)(this.width.Value + 10) + "\">\n" +
										"<a href=\"" + fichiers[i] + "\" target=\"blank\">\n" +
										"<img src=\"" + fichiers[i] + "\" width=\"" + this.width.Value.ToString() + "\" height=\"" + this.height.Value.ToString() + "\" />\n" +
										"</a>\n" +
										"</td>\n" +
										"<td>\n" +
										this.commentaire.Text +
										"</td>" +
										"</tr>");
							}
							catch
							{
							}
							
							i++;
							RefreshPage();
						}
						else
							{
								i++;
								RefreshPage();
							}
					}
			}
			else
				{
					sw.Write(	"</table>\n" +
								"</body>\n" +
								"</html>");
					sw.Close();
					this.Close();
				}
		}
		
		private void RefreshPage() {
			try
			{
				System.GC.Collect();
				System.GC.WaitForPendingFinalizers();
				this.image = Image.FromFile(fichiers[i]);
				this.picBox.Image = this.image;
				this.commentaire.Text = "";
				this.chkBox.Checked = false;
			}
			catch
			{
			}
		}
		
		protected override void OnClosed(EventArgs ea) {
			base.OnClosed(ea);
			try
			{
				sw.Close();
			}
			catch
			{
				
			}
		}
	}
}
