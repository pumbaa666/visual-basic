// created on 23/05/2003 at 14:28
using System;
using System.Windows.Forms;

namespace SlideShow {
	public class MainClass
	{
		public static void Main(string[] args)
		{
			string str;
		
			if(args.Length > 0)
			{
				foreach(string s in args)
				{
					str = s;
					if((!IsPicture(str)) && (System.IO.Path.HasExtension(str)))
					{
						MessageBox.Show("Format non reconnu", "SlideShow");
					}
				}
				SlideShow sls = new SlideShow(args);
				Application.Run(sls);
			}
			else
				{
					MessageBox.Show("SlideShow n'est pas independant, glissez-deposez une image dessus.", "SlideShow");
				}
		}
		
		private static bool IsPicture(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".JPG") || path.EndsWith(".JPEG") || path.EndsWith(".BMP") || path.EndsWith(".GIF") || path.EndsWith(".PNG") || path.EndsWith(".ICO"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
	}
}
