namespace System.Windows.Forms
{
	class Separateur : RichMenuItem
	{
		public Separateur()
		{
			this.Text = "-";
		}
	}
}
