// created on 01/06/2003 at 22:19
using System;
using System.Windows.Forms;

namespace MediaViewer {
	public class Filtre : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lbl;
		public System.Windows.Forms.TextBox tb;
		private System.Windows.Forms.Button btn;
		
		public Filtre()
		{
			InitializeComponent();
			this.ClientSize = new System.Drawing.Size(this.btn.Right + 5, this.btn.Bottom + 5);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		}
		
		void InitializeComponent() {
			this.lbl = new Label();
			this.lbl.Parent = this;
			this.lbl.AutoSize = true;
			this.lbl.Text = "Contenant le texte :";
			this.lbl.Location = new System.Drawing.Point(10, 10);
			
			this.tb = new TextBox();
			this.tb.Parent = this;
			this.tb.Width = 150;
			this.tb.Location = new System.Drawing.Point(this.lbl.Right + 5, 10);
			
			this.btn = new Button();
			this.btn.Parent = this;
			this.btn.FlatStyle = FlatStyle.System;
			this.btn.Text = "Ok";
			this.btn.Location = new System.Drawing.Point(this.tb.Right + 5, 10);
			this.btn.DialogResult = System.Windows.Forms.DialogResult.OK;
		}
	}
}
