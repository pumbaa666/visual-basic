using System;
using System.Windows.Forms;

namespace Zoomer
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			try
			{
				Zoomer zoomer = new Zoomer(args[0]);
				Application.Run(zoomer);
			}
			catch
			{
				Console.Out.WriteLine("Utilisation : Zoomer <NomFichier>");
			}
		}
	}
}
