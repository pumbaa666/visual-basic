using Microsoft.Win32;

using System;
using System.Drawing;
using System.Windows.Forms;

namespace SlideShow {
	public class SlideShow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Timer timer;
		
		int i;
		
		Image image;
		
		string[] paths;
		
		public SlideShow(string[] paths) {
			this.i = 0;
			this.ShowInTaskbar = false;
			InitializeComponent();
			InitializeMenus();
			VerifIfDirectory(paths);
		}
		
		private void InitializeComponent() {
			this.timer = new Timer();
			this.timer.Interval = 2500;
			this.timer.Tick += new EventHandler(ChangeImage);
			this.timer.Enabled = true;
		}
		
		private void InitializeMenus() {
			this.Menu = new MainMenu();
			
			MenuItem miFichier = new MenuItem();
			miFichier.Text = "&Fichier";
			
			MenuItem miOption = new MenuItem();
			miOption.Text = "&Options";
			
			RichMenuItem miQuitter = new RichMenuItem();
			miQuitter.Text = "&Quitter";
			miQuitter.Click += new EventHandler(Quitter);
			
			RichMenuItem miTemps = new RichMenuItem();
			miTemps.Text = "&Intervalle entre 2 images";
			miTemps.Click += new EventHandler(ChangeTemps);
			
			RichMenuItem miCouleur = new RichMenuItem();
			miCouleur.Text = "&Changer la couleur de fond";
			miCouleur.Click += new EventHandler(ChangeCouleur);
			
			Menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miFichier,
																			miOption});
			miFichier.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {miQuitter});
			miOption.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {	miTemps,
																				miCouleur});
		}
		
		private void Quitter(object obj, EventArgs ea) {
			Application.Exit();
		}
		
		private void ChangeTemps(object obj, EventArgs ea) {
			TimerDialog td = new TimerDialog();
			td.numTick.Value = this.timer.Interval;
			if((td.ShowDialog() == DialogResult.OK) && (td.numTick.Value != 0))
			{
				this.timer.Interval = (int)td.numTick.Value;
			}
		}
		
		private void ChangeCouleur(object obj, EventArgs ea) {
			ColorDialog clrdlg = new ColorDialog();
			if(clrdlg.ShowDialog() == DialogResult.OK)
			{
				this.BackColor = clrdlg.Color;
			}
		}
		
		private void ChangeImage(object obj, EventArgs ea) {
			if(i >= paths.Length)
			{
				i = 0;
			}
				
			try
			{
				this.image = Image.FromFile(paths[i]);
				this.Text = "SlideShow - " + paths[i];
				i++;
				this.Invalidate();
			}
			catch
			{
				i++;
				ChangeImage(obj, ea);
			}
		}
		
		protected override void OnPaint(PaintEventArgs pea) {
			base.OnPaint(pea);
			try
			{
				ScaleIsotropicaly(pea.Graphics, new Rectangle(0, 0, ClientSize.Width, ClientSize.Height));
			}
			catch
			{
				return;
			}
		}
		
		protected override void OnResize(EventArgs ea) {
			base.OnResize(ea);
			this.Invalidate();
		}
		
		private void ScaleIsotropicaly(Graphics grfx, Rectangle rect) {
			SizeF sizef = new SizeF(image.Width / image.HorizontalResolution, image.Height / image.VerticalResolution);
			float fScale = Math.Min(rect.Width / sizef.Width, rect.Height / sizef.Height);
			sizef.Width *= fScale;
			sizef.Height *= fScale;
			grfx.DrawImage(image, rect.X + (rect.Width - sizef.Width) / 2, rect.Y + (rect.Height - sizef.Height) / 2, sizef.Width, sizef.Height);
		}
		
		private void VerifIfDirectory(string[] paths) {
			if(!System.IO.Path.HasExtension(paths[0]))
			{
				this.paths = System.IO.Directory.GetFiles(paths[0]);
			}
			else
				{
					this.paths = paths;
				}
		}
		
		private static bool IsPicture(string path) {
			path = path.ToUpper();
			
			if(path.EndsWith(".JPG") || path.EndsWith(".JPEG") || path.EndsWith(".BMP") || path.EndsWith(".GIF") || path.EndsWith(".PNG") || path.EndsWith(".ICO"))
			{
				return true;
			}
			else
				{
					return false;
				}
		}
	}
}
