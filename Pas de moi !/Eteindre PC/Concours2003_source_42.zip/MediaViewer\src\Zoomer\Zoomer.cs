// created on 23/05/2003 at 15:46
using System;
using System.Drawing;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;

namespace Zoomer {
	public class Zoomer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pictureBox;
		
		private Panel panel;
		private Panel panel2;
		
		private Splitter split;
		
		
		ImageList imgList;
		ResourceManager rm = new ResourceManager("Zoomer", Assembly.GetCallingAssembly());
		
		
		ToolBar toolBar;
		
		int facteur = 100;
		
		Image image;
		string path;
		
		public Zoomer(string imgpath) {
			this.imgList = new ImageList();
			this.imgList.Images.Add((Bitmap)rm.GetObject("z+"));
			this.imgList.Images.Add((Bitmap)rm.GetObject("z-"));
			this.imgList.TransparentColor = Color.Red;
			
			this.toolBar = new ToolBar();
			this.toolBar.Dock = DockStyle.Fill;
			this.toolBar.Height = 20;
			this.toolBar.ImageList = this.imgList;
			this.toolBar.ShowToolTips = true;
			this.toolBar.ButtonClick += new ToolBarButtonClickEventHandler(ToolBarOnClick);
			
			this.panel2 = new Panel();
			this.panel2.Parent = this;
			this.panel2.Dock = DockStyle.Fill;
			this.panel2.AutoScroll = true;
			
			this.split = new Splitter();
			this.split.Parent = this;
			this.split.Enabled = false;
			this.split.Height = 0;
			this.split.Dock = DockStyle.Top;
			
			this.panel = new Panel();
			this.panel.Parent = this;
			this.panel.Dock = DockStyle.Top;
			this.panel.Height = 25;
			
			this.path = imgpath;
			this.image = Image.FromFile(imgpath);
			this.ShowInTaskbar = false;
			this.image = (Image)image;
			this.Text = "Zoom " + facteur + "%";
			
			
			this.toolBar.Parent = this.panel;
			
			InitializeComponent();
			this.pictureBox.Image = this.image;
			
			string[] tooltips = {"Zoom + 10%", "Zoom - 10%"};
			string[] noms = {"zp", "zm"};
			for(int i=0; i<2; i++)
			{
				ToolBarButton tbarbtn = new ToolBarButton();
				tbarbtn.ImageIndex = i;
				tbarbtn.ToolTipText = tooltips[i];
				tbarbtn.Tag = noms[i];
				this.toolBar.Buttons.Add(tbarbtn);
			}
			this.toolBar.BringToFront();
		}
		
		void InitializeComponent() {
			this.pictureBox = new System.Windows.Forms.PictureBox();
			// 
			// pictureBox
			// 
			this.pictureBox.Name = "pictureBox";
			this.pictureBox.Parent = this.panel2;
			this.pictureBox.Size = new System.Drawing.Size(292, 266);
			this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox.TabIndex = 0;
			this.pictureBox.TabStop = false;
			// 
			// Zoomer
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScroll = true;
		}
		
		private void MakeCaption() {
			this.Text = "Zoom - " + this.facteur.ToString() + "%";
		}
		
		protected override void OnPaint(PaintEventArgs pea) {
			base.OnPaint(pea);
			ResizeImage();
		}
		protected override void OnResize(EventArgs ea) {
			base.OnResize(ea);
//			this.panel2.Height = this.ClientSize.Height - this.toolBar.Height;
		}
		
		private void ToolBarOnClick(object obj, ToolBarButtonClickEventArgs tbbcea) {
			ToolBarButton tbb = tbbcea.Button;
			switch(tbb.Tag.ToString())
			{
				case "zp" :	this.facteur += 10;
							break;
				case "zm" :	if(this.facteur >= 10)
							{
								this.facteur -= 10;
							}
							break;
				default:	break;
			}
			ResizeImage();
			MakeCaption();
		}
		
		private void ResizeImage() {
			this.pictureBox.Image = image.GetThumbnailImage((int)((this.image.Width * this.facteur) / 100), (int)((this.image.Height * this.facteur) / 100), null, (IntPtr)0);
		}
		
		protected override void OnClosed(EventArgs ea) {
			base.OnClosed(ea);
			this.image.Dispose();
		}
	}
}
